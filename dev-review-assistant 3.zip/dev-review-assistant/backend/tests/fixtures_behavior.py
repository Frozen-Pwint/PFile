"""
「更新ボタン追加」の PR を再現するテスト用リポジトリ。

master: 受注編集画面(表示のみ)
feature/ISSUE-510-order-update:
  - HTML に「更新」ボタン・入力エラー表示・最終更新日時・ステータス表示を追加
  - TS に入力チェック(Validators)、出荷済みチェック、確認ダイアログ、更新後のメッセージ・再読込を追加
  - C# に更新 API(サーバー側チェック・排他・更新日時)と DTO の入力チェックを追加
"""
from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path

HTML_BEFORE = """<div class="order-edit">
  <h2>受注編集</h2>
  <p>受注番号: {{ order.no }}</p>
</div>
"""

HTML_AFTER = """<div class="order-edit">
  <h2>受注編集</h2>
  <p>受注番号: {{ order.no }}</p>
  <form [formGroup]="form">
    <label>数量 <input formControlName="quantity" type="number"></label>
    @if (form.get('quantity')?.hasError('required')) {
      <span class="error">数量を入力してください</span>
    }
    <span class="error" *ngIf="form.get('quantity')?.hasError('min')">数量は1以上を入力してください</span>
    <label>備考 <textarea formControlName="note"></textarea></label>
    <p>最終更新: {{ order.updatedAt | date:'yyyy/MM/dd HH:mm' }}</p>
    <span class="status" [class.cancelled]="order.status === 'C'">{{ statusLabel(order.status) }}</span>
    <button type="button" (click)="update()" [disabled]="form.invalid || saving">更新</button>
  </form>
</div>
"""

TS_BEFORE = """import { Component, inject } from '@angular/core';

@Component({ selector: 'app-order-edit', templateUrl: './order-edit.component.html' })
export class OrderEditComponent {
  order!: Order;
}
"""

TS_AFTER = """import { Component, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({ selector: 'app-order-edit', templateUrl: './order-edit.component.html' })
export class OrderEditComponent {
  private fb = inject(FormBuilder);
  order!: Order;
  saving = false;
  form = this.fb.group({
    quantity: [null, [Validators.required, Validators.min(1), Validators.max(9999)]],
    note: ['', Validators.maxLength(200)],
  });

  update(): void {
    if (this.order.status === 'S') {
      this.message.error('出荷済みの受注は更新できません');
      return;
    }
    if (!confirm('受注を更新します。よろしいですか？')) {
      return;
    }
    this.saving = true;
    this.http.put<Order>(`/api/orders/${this.order.id}`, this.form.value).subscribe({
      next: (res) => {
        this.message.success('更新しました');
        this.order = res;
        this.loadHistory();
        this.form.markAsPristine();
        this.saving = false;
      },
      error: (e) => {
        this.message.error(e.error?.message ?? '更新に失敗しました');
        this.saving = false;
      },
    });
  }

  statusLabel(s: string): string {
    return s === 'C' ? '取消' : '受注';
  }

  loadHistory(): void {
    this.history = [];
  }
}
"""

CS_CONTROLLER_BEFORE = """using Microsoft.AspNetCore.Mvc;

namespace Erp.Api.Controllers
{
    [ApiController]
    public class OrderController : ControllerBase
    {
        [HttpGet("api/orders/{id}")]
        public IActionResult Get(int id)
        {
            return Ok(_repo.Find(id));
        }
    }
}
"""

CS_CONTROLLER_AFTER = """using Microsoft.AspNetCore.Mvc;

namespace Erp.Api.Controllers
{
    [ApiController]
    public class OrderController : ControllerBase
    {
        [HttpGet("api/orders/{id}")]
        public IActionResult Get(int id)
        {
            return Ok(_repo.Find(id));
        }

        [HttpPut("api/orders/{id}")]
        public IActionResult Update(int id, OrderUpdateDto dto)
        {
            if (dto.Quantity <= 0) return BadRequest("数量は1以上を指定してください");
            var order = _repo.Find(id);
            if (order == null) return NotFound();
            if (order.Status == "S") throw new BusinessException("出荷済みの受注は更新できません");
            if (order.RowVersion != dto.RowVersion)
                return Conflict("他のユーザーが更新しています。再読込してください");
            order.Quantity = dto.Quantity;
            order.UpdatedAt = DateTime.Now;
            order.UpdatedBy = _user.Name;
            _repo.Save(order);
            return Ok(order);
        }
    }
}
"""

CS_DTO_AFTER = """using System.ComponentModel.DataAnnotations;

namespace Erp.Api.Dtos
{
    public class OrderUpdateDto
    {
        [Required(ErrorMessage = "数量は必須です")]
        [Range(1, 9999, ErrorMessage = "数量は1〜9999で入力してください")]
        public int Quantity { get; set; }

        [StringLength(200)]
        public string Note { get; set; }

        public byte[] RowVersion { get; set; }
    }
}
"""

FILES_BEFORE = {
    "web/src/app/order/order-edit.component.html": HTML_BEFORE,
    "web/src/app/order/order-edit.component.ts": TS_BEFORE,
    "src/Erp.Api/Controllers/OrderController.cs": CS_CONTROLLER_BEFORE,
}
FILES_AFTER = {
    "web/src/app/order/order-edit.component.html": HTML_AFTER,
    "web/src/app/order/order-edit.component.ts": TS_AFTER,
    "src/Erp.Api/Controllers/OrderController.cs": CS_CONTROLLER_AFTER,
    "src/Erp.Api/Dtos/OrderUpdateDto.cs": CS_DTO_AFTER,
}
FEATURE = "feature/ISSUE-510-order-update"


def _git(cwd, *args):
    subprocess.run(["git", *args], cwd=cwd, check=True, capture_output=True)


def _write(root: Path, files: dict[str, str]) -> None:
    for rel, text in files.items():
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding="utf-8")


def make_update_button_repo() -> str:
    root = Path(tempfile.mkdtemp())
    _git(root, "init", "-q", "--bare", "-b", "master", "origin.git")
    work = root / "work"
    _git(root, "clone", "-q", "origin.git", "work")
    _git(work, "config", "user.email", "t@example.com")
    _git(work, "config", "user.name", "tester")
    _git(work, "checkout", "-q", "-B", "master")
    _write(work, FILES_BEFORE)
    _git(work, "add", "-A"); _git(work, "commit", "-qm", "受注編集画面"); _git(work, "push", "-q", "origin", "master")
    _git(work, "checkout", "-qb", FEATURE)
    _write(work, FILES_AFTER)
    _git(work, "add", "-A"); _git(work, "commit", "-qm", "#510 受注編集に更新ボタンを追加")
    _git(work, "push", "-q", "origin", FEATURE)
    _git(work, "checkout", "-q", "master")
    return str(work)
