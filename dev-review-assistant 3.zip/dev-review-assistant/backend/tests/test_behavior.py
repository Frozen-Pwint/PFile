"""
操作ごとの「更新前チェック」「更新後の表示」抽出のテスト。

実行:  cd backend && python -m unittest discover -s tests -v
"""
from __future__ import annotations

import os
import tempfile
import unittest

os.environ.setdefault("CHECKLIST_OUTPUT_DIR", tempfile.mkdtemp())

from fixtures_behavior import FEATURE, make_update_button_repo  # noqa: E402

from app import git_diff as g  # noqa: E402
from app.behavior import FAIL, PRE, VIEW, extract_scenarios  # noqa: E402
from app.checklist import generate_checklist  # noqa: E402
from app.llm_checklist import refine_scenario  # noqa: E402


class FakeClient:
    model = "gpt-oss:20b"
    base_url = "http://fake"

    def __init__(self, items):
        self.items = items

    def chat_json(self, system, user):
        return {"title": "受注編集画面の「更新」ボタン", "items": self.items}


class BehaviorTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.repo = make_update_button_repo()
        cls.feature = "origin/" + FEATURE
        files = g.get_full_diff(cls.repo, "origin/master", cls.feature)
        cls.scenarios = extract_scenarios(files, lambda p: g.show_file(cls.repo, cls.feature, p))

    def _update(self):
        return next(sc for sc in self.scenarios if "更新" in sc.title)

    def _checks(self, items):
        return "\n".join(i.check for i in items)

    def test_trigger_chain(self):
        sc = self._update()
        self.assertIn("update()", sc.trigger)
        self.assertIn("PUT /api/orders/", sc.trigger)
        self.assertIn("Update()", sc.trigger)          # C# のエンドポイントまでたどれている

    def test_pre_checks(self):
        pre = self._checks(self._update().pre_checks)
        self.assertIn("出荷済みの受注は更新できません", pre)                    # TS のガード
        self.assertIn("確認ダイアログ『受注を更新します。よろしいですか？』", pre)  # confirm
        self.assertIn("「quantity」が 1 未満のときエラー", pre)                  # Validators.min
        self.assertIn("『数量を入力してください』", pre)                         # HTML の @if エラー表示
        self.assertIn("`form.invalid || saving` のとき「更新」ボタンが押せない", pre)
        self.assertIn("サーバー側: `dto.Quantity <= 0`", pre)                    # C# のガード
        self.assertIn("1〜9999 の範囲外", pre)                                  # DTO の [Range]
        self.assertIn("排他エラー", pre)
        self.assertEqual(pre.count("排他エラー"), 1)                             # プロパティ宣言は対象外

    def test_post_effects(self):
        post = self._update().post_effects
        after = self._checks([i for i in post if i.category not in (VIEW, FAIL)])
        self.assertIn("更新後に『更新しました』が表示されること", after)
        self.assertIn("this.loadHistory()", after)
        self.assertIn("UpdatedAt", after)
        view = self._checks([i for i in post if i.category == VIEW])
        self.assertIn("最終更新:", view)                      # 同じ画面の表示変更も更新後の確認に含める
        fail = self._checks([i for i in post if i.category == FAIL])
        self.assertIn("『更新に失敗しました』", fail)
        self.assertEqual(after.count("処理中の表示が解除"), 1)  # 重複除去

    def test_pre_order_screen_then_server(self):
        files = [i.file.rsplit(".", 1)[-1] for i in self._update().pre_checks]
        self.assertEqual(files, sorted(files, key=lambda x: {"html": 0, "ts": 1, "cs": 2}[x]))

    def test_refine_keeps_uncovered_rule_items(self):
        sc = extract_scenarios(g.get_full_diff(self.repo, "origin/master", self.feature),
                               lambda p: g.show_file(self.repo, self.feature, p))[0]
        before = len(sc.pre_checks)
        refine_scenario(FakeClient([
            {"category": "更新前チェック", "check": "数量 0 → エラー、1 → 更新できること", "severity": "high",
             "file": "order-edit.component.ts", "line": 10},
            {"category": "更新後の表示", "check": "『更新しました』が表示されること", "severity": "medium",
             "file": "order-edit.component.ts", "line": 25},
        ]), sc)
        self.assertEqual(sc.title, "受注編集画面の「更新」ボタン")
        self.assertEqual(sc.pre_checks[0].source, "ai")
        # L10 の Validators 3 件は AI の 1 件にまとまり、他のルール項目は残る
        self.assertEqual(len(sc.pre_checks), before - 3 + 1)  # L10 の required/min/max の 3 件 → AI の 1 件
        self.assertTrue(any(i.source == "rule" and "排他" in i.check for i in sc.pre_checks))

    def test_markdown_and_index(self):
        r = generate_checklist(self.repo, "origin/master", self.feature, issue="510", use_llm=False)
        md = r.markdown
        self.assertIn("## 2. 動作確認(操作ごとの更新前チェック・更新後の表示)", md)
        self.assertIn("**更新前チェック(条件を満たさないときは更新されないこと)**", md)
        self.assertIn("**更新後の表示(正常に更新されたとき)**", md)
        self.assertIn("## 3. ファイル別チェック", md)
        items = (r.common_items + [i for sc in r.scenarios for i in sc.pre_checks + sc.post_effects]
                 + [i for v in r.file_items.values() for i in v] + r.test_items)
        # 画面でのチェック状態を Markdown に反映するため、idx は Markdown の - [ ] の順番と一致している必要がある
        self.assertEqual(sorted(i.idx for i in items), list(range(md.count("- [ ] "))))
        d = r.to_dict()
        self.assertIn("scenarios", d)
        self.assertTrue(d["scenarios"][0]["pre_checks"])
        try:
            from app.schemas import ChecklistResult as ResultSchema
        except ImportError:  # pydantic 未インストール
            return
        self.assertTrue(ResultSchema.model_validate(d).scenarios[0].pre_checks)


if __name__ == "__main__":
    unittest.main()
