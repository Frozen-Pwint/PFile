"""
操作ごとの「更新前チェック」「更新後の表示」を差分から抽出する(ルールベース)。

例: 差分に「更新」ボタンが追加され、更新前の入力チェックと更新後のメッセージ表示が
実装されている場合、次のようなチェック項目を作る。

    操作: 「更新」ボタン  (order-edit.component.html L7 → update() → PUT /api/orders/{id} → OrderController.Update)
      更新前チェック
        - 数量: 未入力のとき更新できないこと(Validators.required)
        - `this.order.status === 'S'` のとき『出荷済みの受注は更新できません』が表示され、更新されないこと
        - 確認ダイアログ『受注を更新します。よろしいですか？』でキャンセルした場合、更新されないこと
      更新後の表示
        - 『更新しました』が表示されること
        - 再読込(this.loadHistory())で最新の内容が表示されること
      更新失敗時
        - 『更新に失敗しました』が表示されること

手順:
  1. 追加行から「根拠(Evidence)」を抽出する(TS / HTML / C#)
  2. HTML のボタン → TS のハンドラー → API の URL → C# のエンドポイント → DTO/サービス
     をたどって、根拠を操作(Scenario)ごとにまとめる
  3. どの操作にも属さない根拠はファイル単位の「その他の変更」にまとめる
AI が使える場合は llm_checklist.refine_scenario で具体的なテスト項目に書き直す。
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import PurePosixPath
from typing import Callable, Optional

from .git_diff import DiffLine, FileDiff
from .models import ChecklistItem

PRE = "更新前チェック"
POST = "更新後の表示"
FAIL = "更新失敗時"
VIEW = "表示の変更"

MAX_VIEW_ITEMS_PER_FILE = 8


@dataclass
class Evidence:
    kind: str           # PRE / POST / FAIL / VIEW
    check: str          # チェック項目の文
    file: str
    line: int
    code: str           # 根拠のコード(1 行)
    severity: str = "medium"

    def to_item(self) -> ChecklistItem:
        return ChecklistItem(
            check=self.check, category=self.kind, severity=self.severity,
            reason=f"根拠: `{_short(self.code, 90)}`", file=self.file, lines=[self.line],
            source="rule", rule_id="BEHAVIOR",
        )


@dataclass
class Trigger:
    label: str          # ボタンの文言(例: 更新)
    handler: str        # ハンドラー名(例: update)
    file: str
    line: int


@dataclass
class Scenario:
    key: str
    title: str                       # 例: 「更新」ボタン
    trigger: str                     # 例: order-edit.component.html L7 → update() → PUT /api/orders/{id}
    evidences: list[Evidence] = field(default_factory=list)
    code_context: list[str] = field(default_factory=list)   # AI に渡すコード(メソッド本体など)
    pre_checks: list[ChecklistItem] = field(default_factory=list)
    post_effects: list[ChecklistItem] = field(default_factory=list)

    def build_items_from_evidence(self) -> None:
        self.pre_checks = [e.to_item() for e in self.evidences if e.kind == PRE]
        self.post_effects = [e.to_item() for e in self.evidences if e.kind in (POST, FAIL, VIEW)]

    def to_dict(self) -> dict:
        return {
            "key": self.key, "title": self.title, "trigger": self.trigger,
            "pre_checks": [i.to_dict() for i in self.pre_checks],
            "post_effects": [i.to_dict() for i in self.post_effects],
        }


# ---------------------------------------------------------------------------
# 共通ユーティリティ
# ---------------------------------------------------------------------------

_STR_RE = re.compile(r"'((?:[^'\\]|\\.)*)'|\"((?:[^\"\\]|\\.)*)\"|`([^`]*)`")
_JP_RE = re.compile(r"[ぁ-んァ-ヶ一-龠ー]")


def _short(s: str, n: int) -> str:
    s = s.strip()
    return s if len(s) <= n else s[: n - 1] + "…"


def _message(line: str) -> str:
    """行内の文字列リテラルから、画面に出るメッセージらしいものを返す。"""
    found = [next(x for x in m.groups() if x is not None) for m in _STR_RE.finditer(line)]
    found = [f for f in found if f.strip()]
    for f in found:
        if _JP_RE.search(f) or " " in f.strip():
            return f.strip()
    return ""


def _paren_content(text: str, start: int) -> str:
    """text[start] が '(' のとき、対応する ')' までの中身を返す。"""
    depth = 0
    for i in range(start, len(text)):
        c = text[i]
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
            if depth == 0:
                return text[start + 1: i]
    return text[start + 1:]


def _if_condition(line: str) -> Optional[str]:
    m = re.search(r"\bif\s*\(", line)
    if not m:
        return None
    return _paren_content(line, m.end() - 1).strip()


def _strip_tags(html: str) -> str:
    t = re.sub(r"<[^>]*>", " ", html)
    t = re.sub(r"\{\{.*?\}\}", " ", t)
    t = re.sub(r"[{}]", " ", t)
    t = re.sub(r"@\w+\s*(\([^)]*\))?", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def _block_range(content: str, start_line: int) -> tuple[int, int]:
    """start_line(1 始まり)から始まる { ... } ブロックの行範囲を返す(文字列・コメントは簡易スキップ)。"""
    lines = content.splitlines()
    depth, opened = 0, False
    for ln in range(start_line, len(lines) + 1):
        text = lines[ln - 1]
        i, quote = 0, None
        while i < len(text):
            c = text[i]
            if quote:
                if c == "\\":
                    i += 2
                    continue
                if c == quote:
                    quote = None
            elif c in "'\"`":
                quote = c
            elif text.startswith("//", i):
                break
            elif c == "{":
                depth += 1
                opened = True
            elif c == "}":
                depth -= 1
                if opened and depth == 0:
                    return start_line, ln
            i += 1
    return start_line, len(lines)


_TS_METHOD_RE = re.compile(
    r"^\s*(?:(?:public|private|protected|static|override|readonly)\s+)*(?:async\s+)?(\w+)\s*\([^)]*\)\s*(?::\s*[^{=]+)?\{")
_CS_METHOD_RE = re.compile(
    r"^\s*(?:(?:public|private|protected|internal|static|virtual|override|async|sealed)\s+)+[\w<>\[\],.? ]+?\s+(\w+)\s*\(")
_TS_KEYWORDS = {"if", "for", "while", "switch", "catch", "function", "return", "constructor"}


def _methods(content: str, lang: str) -> dict[str, tuple[int, int]]:
    """ファイル全文からメソッド名 → (開始行, 終了行) を返す。"""
    result: dict[str, tuple[int, int]] = {}
    regex = _TS_METHOD_RE if lang == "typescript" else _CS_METHOD_RE
    for n, text in enumerate(content.splitlines(), 1):
        m = regex.match(text)
        if m and m.group(1) not in _TS_KEYWORDS and m.group(1) not in result:
            result[m.group(1)] = _block_range(content, n)
    return result


def _added(fd: FileDiff) -> list[DiffLine]:
    return [l for l in fd.added_lines if l.new_lineno is not None]


def _next_added(added: list[DiffLine], idx: int, count: int) -> list[DiffLine]:
    """idx の次から、行番号が連続している追加行を最大 count 行返す。"""
    out, prev = [], added[idx].new_lineno
    for l in added[idx + 1: idx + 1 + count]:
        if l.new_lineno != prev + 1:
            break
        out.append(l)
        prev = l.new_lineno
    return out


# ---------------------------------------------------------------------------
# TypeScript (Angular)
# ---------------------------------------------------------------------------

_ERR_CALL_RE = re.compile(r"\.(error|warn|warning|showError|showWarning|danger)\s*\(|\balert\s*\(|errorMessage\s*=|\bthrow\b")
_OK_CALL_RE = re.compile(r"\.(success|info|showSuccess|showInfo|showMessage|notify|toast\w*|open|add)\s*\(|\balert\s*\(")
_CONFIRM_RE = re.compile(r"\bconfirm\s*\(|\.(confirm|openConfirm|showConfirm)\s*\(|ConfirmDialog")
_HTTP_RE = re.compile(r"\.(get|post|put|delete|patch)\s*(?:<[^>]*>)?\s*\(\s*[`'\"]([^`'\"]+)")
_VALIDATOR_RE = re.compile(
    r"Validators\.(requiredTrue|required|email|minLength|maxLength|min|max|pattern)\b(?:\(([^)]*)\))?")
_ASYNC_START_RE = re.compile(r"\.subscribe\s*\(|\bnext\s*:|\.then\s*\(|\bawait\s+(?:firstValueFrom|lastValueFrom|this\.)")
_ASYNC_ERROR_RE = re.compile(r"\berror\s*:|catchError|\.catch\s*\(|\bcatch\s*\(")


def _validator_text(field_name: str, kind: str, arg: str) -> tuple[str, str]:
    f = f"「{field_name}」" if field_name else "入力項目"
    arg = (arg or "").strip()
    texts = {
        "required": (f"{f}が未入力のとき、エラーになり更新できないこと", "high"),
        "requiredTrue": (f"{f}をチェックしていないとき、更新できないこと", "medium"),
        "email": (f"{f}にメール形式でない値を入れたとき、エラーになること", "medium"),
        "minLength": (f"{f}が {arg} 文字未満のときエラー、{arg} 文字ちょうどで更新できること(境界値)", "medium"),
        "maxLength": (f"{f}が {arg} 文字を超えるときエラー、{arg} 文字ちょうどで更新できること(境界値)", "medium"),
        "min": (f"{f}が {arg} 未満のときエラー、{arg} ちょうどで更新できること(境界値)", "high"),
        "max": (f"{f}が {arg} を超えるときエラー、{arg} ちょうどで更新できること(境界値)", "medium"),
        "pattern": (f"{f}が形式 {arg} に合わない値のとき、エラーになること", "medium"),
    }
    return texts.get(kind, (f"{f}の入力チェック({kind})が正しく動くこと", "medium"))


def _ts_evidence(fd: FileDiff) -> list[Evidence]:
    ev: list[Evidence] = []
    added = _added(fd)
    async_until = -1        # この行番号までは「非同期処理の結果(更新後)」とみなす
    error_until = -1        # この行番号までは「失敗時の処理」とみなす
    for idx, l in enumerate(added):
        text, n = l.content, l.new_lineno
        code = text.strip()
        if not code or code.startswith("//"):
            continue

        # --- 入力チェック(Reactive Forms の Validators)
        if "Validators." in text:
            fm = re.search(r"['\"]?(\w+)['\"]?\s*:\s*(?:\[|new\s+FormControl)", text)
            fname = fm.group(1) if fm else ""
            for vm in _VALIDATOR_RE.finditer(text):
                check, sev = _validator_text(fname, vm.group(1), vm.group(2) or "")
                ev.append(Evidence(PRE, check, fd.path, n, code, sev))
            continue

        # --- 確認ダイアログ
        if _CONFIRM_RE.search(text):
            msg = _message(text)
            check = (f"確認ダイアログ『{msg}』が表示され、キャンセルした場合は更新されないこと" if msg
                     else "確認ダイアログが表示され、キャンセルした場合は更新されないこと")
            ev.append(Evidence(PRE, check, fd.path, n, code, "medium"))
            continue

        # --- 非同期処理(API 呼び出し)の結果部分の判定(次のメソッド定義で打ち切る)
        if _TS_METHOD_RE.match(text):
            async_until = error_until = -1
        if _ASYNC_START_RE.search(text):
            async_until = n + 25
        if _ASYNC_ERROR_RE.search(text):
            error_until = n + 4

        # --- ガード条件: if (...) { エラー表示; return; }
        cond = _if_condition(text)
        if cond is not None and not _CONFIRM_RE.search(cond):
            window = [text] + [x.content for x in _next_added(added, idx, 5)]
            msg_line = next((w for w in window if _ERR_CALL_RE.search(w) and _message(w)), "")
            stops = any(re.search(r"\breturn\b|\bthrow\b", w) for w in window)
            if msg_line or stops:
                if n <= error_until:
                    pass  # 失敗時処理の中の if は下で FAIL として扱う
                elif n <= async_until:
                    pass  # 結果処理中の分岐は、下の個別判定に任せる
                else:
                    msg = _message(msg_line) if msg_line else ""
                    check = (f"`{_short(cond, 60)}` のとき『{msg}』が表示され、更新されないこと" if msg
                             else f"`{_short(cond, 60)}` のとき処理が中断され、更新されないこと")
                    ev.append(Evidence(PRE, check, fd.path, n, code, "high" if msg else "medium"))
                    continue

        in_error = n <= error_until
        in_async = n <= async_until

        # --- 失敗時の表示
        if in_error and (_ERR_CALL_RE.search(text) or _OK_CALL_RE.search(text)):
            msg = _message(text)
            check = (f"更新に失敗したとき『{msg}』が表示されること" if msg
                     else "更新に失敗したとき、エラー内容が画面に表示されること(サーバーのメッセージを含む)")
            ev.append(Evidence(FAIL, check, fd.path, n, code, "medium"))
            continue

        if not in_async:
            # 処理中フラグ(二重実行防止)
            if re.search(r"this\.(saving|loading|busy|processing|isSaving|isLoading|submitting)\s*=\s*true", text):
                ev.append(Evidence(PRE, "処理中は再度押せない(二重に更新されない)こと", fd.path, n, code, "medium"))
            continue

        # --- 更新後(成功時)の表示
        if _OK_CALL_RE.search(text) and not _ERR_CALL_RE.search(text.replace("alert(", "")):
            msg = _message(text)
            if msg:
                ev.append(Evidence(POST, f"更新後に『{msg}』が表示されること", fd.path, n, code, "medium"))
                continue
        nav = re.search(r"navigate(?:ByUrl)?\s*\(\s*\[?\s*[`'\"]([^`'\"]+)", text)
        if nav:
            ev.append(Evidence(POST, f"更新後に `{nav.group(1)}` の画面へ遷移すること", fd.path, n, code, "medium"))
            continue
        if re.search(r"dialogRef\.close|\.close\s*\(", text):
            ev.append(Evidence(POST, "更新後にダイアログが閉じ、呼び出し元の画面に結果が反映されること", fd.path, n, code, "medium"))
            continue
        rl = re.search(r"this\.((?:load|reload|refresh|search|fetch|get|init)\w*)\s*\(", text)
        if rl:
            ev.append(Evidence(POST, f"更新後に再読込(`this.{rl.group(1)}()`)され、最新の内容が表示されること",
                               fd.path, n, code, "medium"))
            continue
        if re.search(r"\.(reset|markAsPristine)\s*\(", text):
            ev.append(Evidence(POST, "更新後に入力内容がリセット(未変更の状態)になること", fd.path, n, code, "low"))
            continue
        flag = re.search(r"this\.(saving|loading|busy|processing|isSaving|isLoading|submitting)\s*=\s*false", text)
        if flag:
            ev.append(Evidence(POST, "更新完了後(成功・失敗とも)に処理中の表示が解除され、再度操作できること",
                               fd.path, n, code, "low"))
            continue
        asg = re.search(r"this\.([\w.]+)\s*=\s*(?!=)", text)
        if asg:
            ev.append(Evidence(POST, f"更新後に `{asg.group(1)}` の内容が画面に反映されること", fd.path, n, code, "medium"))
    return ev


def _ts_http_calls(content: str, start: int, end: int) -> list[tuple[str, str]]:
    """メソッド範囲内の HTTP 呼び出し (verb, url) を返す。"""
    lines = content.splitlines()[start - 1: end]
    out = []
    for t in lines:
        m = _HTTP_RE.search(t)
        if m and ("http" in t.lower() or "api" in t.lower()):
            out.append((m.group(1).upper(), m.group(2)))
    return out


def _ts_called_methods(content: str, start: int, end: int) -> set[str]:
    body = "\n".join(content.splitlines()[start - 1: end])
    return set(re.findall(r"this\.(\w+)\s*\(", body)) | set(re.findall(r"this\.\w+\.(\w+)\s*\(", body))


# ---------------------------------------------------------------------------
# HTML (Angular テンプレート)
# ---------------------------------------------------------------------------

_BUTTON_RE = re.compile(r"<(button|a|input)\b[^>]*\((click|ngSubmit)\)\s*=\s*\"(\w+)\s*\(")
_FORM_SUBMIT_RE = re.compile(r"\(ngSubmit\)\s*=\s*\"(\w+)\s*\(")
_ERRORISH_RE = re.compile(r"hasError|\.errors|\binvalid\b|\btouched\b|\bdirty\b|error", re.IGNORECASE)


def _html_evidence(fd: FileDiff) -> tuple[list[Evidence], list[Trigger]]:
    ev: list[Evidence] = []
    triggers: list[Trigger] = []
    view_count = 0
    added = _added(fd)
    for idx, l in enumerate(added):
        text, n = l.content, l.new_lineno
        code = text.strip()
        if not code or code.startswith("<!--"):
            continue

        bm = _BUTTON_RE.search(text) or _FORM_SUBMIT_RE.search(text)
        if bm:
            handler = bm.group(3) if bm.re is _BUTTON_RE else bm.group(1)
            label = _strip_tags(text)
            if not label:
                nxt = _next_added(added, idx, 1)
                label = _strip_tags(nxt[0].content) if nxt else ""
            label = _message(f'"{label}"') or label or handler
            triggers.append(Trigger(label=label, handler=handler, file=fd.path, line=n))
            dm = re.search(r"\[disabled\]\s*=\s*\"([^\"]+)\"", text)
            if dm:
                ev.append(Evidence(PRE, f"`{_short(dm.group(1), 60)}` のとき「{label}」ボタンが押せないこと",
                                   fd.path, n, code, "medium"))
            continue

        # 条件付き表示(*ngIf / @if)
        cm = re.search(r"\*ngIf\s*=\s*\"([^\"]+)\"", text) or re.search(r"@if\s*\((.+?)\)\s*\{", text)
        if cm:
            cond = cm.group(1)
            msg = _strip_tags(text[cm.end():] if text.lstrip().startswith("@") else text)
            if not msg:
                nxt = _next_added(added, idx, 1)
                msg = _strip_tags(nxt[0].content) if nxt else ""
            if _ERRORISH_RE.search(cond):
                check = (f"`{_short(cond, 60)}` のとき『{msg}』が表示され、更新できないこと" if msg
                         else f"`{_short(cond, 60)}` のときエラー表示になり、更新できないこと")
                ev.append(Evidence(PRE, check, fd.path, n, code, "medium"))
            elif view_count < MAX_VIEW_ITEMS_PER_FILE:
                view_count += 1
                what = f"『{msg}』" if msg else "この部分"
                ev.append(Evidence(VIEW, f"`{_short(cond, 60)}` のときだけ{what}が表示され、それ以外では表示されないこと",
                                   fd.path, n, code, "low"))
            continue

        if view_count >= MAX_VIEW_ITEMS_PER_FILE:
            continue
        clm = re.search(r"\[class\.([\w-]+)\]\s*=\s*\"([^\"]+)\"", text)
        if clm:
            view_count += 1
            ev.append(Evidence(VIEW, f"`{_short(clm.group(2), 60)}` のとき見た目(`{clm.group(1)}`)が切り替わること",
                               fd.path, n, code, "low"))
            continue
        if "[ngClass]" in text or "[style." in text:
            view_count += 1
            ev.append(Evidence(VIEW, "状態に応じて見た目(色・スタイル)が正しく切り替わること", fd.path, n, code, "low"))
            continue
        for im in re.finditer(r"\{\{\s*(.+?)\s*\}\}", text):
            expr = im.group(1)
            label = _strip_tags(text)
            pipe = re.search(r"\|\s*(\w+)(?::\s*'([^']*)')?", expr)
            what = f"「{label}」" if label else f"`{_short(expr.split('|')[0].strip(), 40)}`"
            if pipe:
                fmt = f"書式 {pipe.group(1)}" + (f"('{pipe.group(2)}')" if pipe.group(2) else "")
                check = f"{what}が{fmt}で表示されること(値が空のときの表示も確認)"
            else:
                check = f"{what}に正しい値が表示されること(更新後の値・値が空のときの表示も確認)"
            view_count += 1
            ev.append(Evidence(VIEW, check, fd.path, n, code, "low"))
            break
    return ev, triggers


# ---------------------------------------------------------------------------
# C# (ASP.NET)
# ---------------------------------------------------------------------------

_CS_HTTP_ATTR_RE = re.compile(r"\[\s*Http(Get|Post|Put|Delete|Patch)\s*(?:\(\s*\"([^\"]*)\")?")
_CS_RETURN_ERR_RE = re.compile(r"\breturn\s+(BadRequest|NotFound|Conflict|Forbid|Unauthorized|UnprocessableEntity|StatusCode|Problem|ValidationProblem)\b")
_CS_ATTR_RE = re.compile(r"\[\s*(Required|Range|StringLength|MaxLength|MinLength|RegularExpression|EmailAddress|Compare)\b(?:\(([^\]]*)\))?\s*\]")


def _cs_attr_text(prop: str, attr: str, args: str) -> tuple[str, str]:
    p = f"「{prop}」" if prop else "項目"
    msg = re.search(r"ErrorMessage\s*=\s*\"([^\"]+)\"", args or "")
    m = f"(メッセージ『{msg.group(1)}』)" if msg else ""
    nums = re.findall(r"-?\d+(?:\.\d+)?", re.sub(r"ErrorMessage\s*=\s*\"[^\"]*\"", "", args or ""))
    if attr == "Required":
        return f"サーバー側: {p}が未指定のとき、エラーで更新されないこと{m}", "high"
    if attr == "Range" and len(nums) >= 2:
        return f"サーバー側: {p}が {nums[0]}〜{nums[1]} の範囲外のときエラー、境界値 {nums[0]} / {nums[1]} では更新できること{m}", "high"
    if attr in ("StringLength", "MaxLength") and nums:
        return f"サーバー側: {p}が {nums[0]} 文字を超えるときエラーになること{m}", "medium"
    if attr == "MinLength" and nums:
        return f"サーバー側: {p}が {nums[0]} 文字未満のときエラーになること{m}", "medium"
    return f"サーバー側: {p}の入力チェック({attr})が正しく動くこと{m}", "medium"


def _cs_evidence(fd: FileDiff) -> list[Evidence]:
    ev: list[Evidence] = []
    added = _added(fd)
    for idx, l in enumerate(added):
        text, n = l.content, l.new_lineno
        code = text.strip()
        if not code or code.startswith("//"):
            continue

        am = _CS_ATTR_RE.search(text)
        if am:
            prop = ""
            for nx in _next_added(added, idx, 4):
                pm = re.search(r"public\s+[\w<>\[\]?,. ]+\s+(\w+)\s*\{", nx.content)
                if pm:
                    prop = pm.group(1)
                    break
            check, sev = _cs_attr_text(prop, am.group(1), am.group(2) or "")
            ev.append(Evidence(PRE, check, fd.path, n, code, sev))
            continue

        fv = re.search(r"RuleFor\s*\(\s*\w+\s*=>\s*\w+\.(\w+)\s*\)(.*)", text)
        if fv:
            rest = fv.group(2)
            msg = re.search(r"WithMessage\s*\(\s*\"([^\"]+)\"", rest)
            rules = ", ".join(re.findall(r"\.(\w+)\s*\(", rest.split("WithMessage")[0])) or "検証ルール"
            check = f"サーバー側: 「{fv.group(1)}」が {rules} を満たさないときエラーになること" + (f"(『{msg.group(1)}』)" if msg else "")
            ev.append(Evidence(PRE, check, fd.path, n, code, "high"))
            continue

        if re.search(r"ModelState\.AddModelError", text):
            msg = _message(text)
            ev.append(Evidence(PRE, f"サーバー側: 入力エラー『{msg}』が画面に表示され、更新されないこと" if msg
                               else "サーバー側: 入力エラーが画面に表示され、更新されないこと", fd.path, n, code, "high"))
            continue

        if (re.search(r"DbUpdateConcurrencyException|\[Timestamp\]|ConcurrencyCheck", text)
                or (re.search(r"RowVersion", text) and re.search(r"\bif\b|\bcatch\b|==|!=", text))):
            window = [text] + [x.content for x in _next_added(added, idx, 3)]
            msg = next((_message(w) for w in window if _message(w)), "")
            ev.append(Evidence(PRE, "他のユーザーが先に更新していた場合、上書きされずに排他エラーになること"
                               + (f"(『{msg}』)" if msg else "(再読込の案内が出ること)"), fd.path, n, code, "high"))
            continue

        cond = _if_condition(text)
        if cond is not None:
            window = [text] + [x.content for x in _next_added(added, idx, 3)]
            err = next((w for w in window if _CS_RETURN_ERR_RE.search(w) or re.search(r"\bthrow\s+new\b", w)), "")
            if err:
                msg = _message(err)
                kind = _CS_RETURN_ERR_RE.search(err)
                result = kind.group(1) if kind else (re.search(r"throw\s+new\s+(\w+)", err).group(1))
                check = (f"サーバー側: `{_short(cond, 60)}` のとき『{msg}』でエラーになり、更新されないこと" if msg
                         else f"サーバー側: `{_short(cond, 60)}` のとき {result} になり、更新されないこと")
                ev.append(Evidence(PRE, check, fd.path, n, code, "high"))
                continue

        asg = re.search(r"\b\w+\.(Updated?(?:At|By|Date|User|Time|Dt)|Upd\w*|Modified\w*|Status|State)\s*=\s*([^;]+);", text)
        if asg:
            name = asg.group(1)
            if name.lower().startswith(("status", "state")):
                check = f"更新後に状態(`{name}`)が `{_short(asg.group(2), 30)}` に変わり、画面の表示にも反映されること"
            else:
                check = f"更新後に `{name}` が記録され、画面に表示される場合は最新の値になること"
            ev.append(Evidence(POST, check, fd.path, n, code, "medium"))
    return ev


def _cs_endpoints(content: str) -> list[dict]:
    """C# ファイル全文からエンドポイント(verb, route, method, 行範囲, 引数の型)を返す。"""
    lines = content.splitlines()
    out = []
    class_route = ""
    for n, text in enumerate(lines, 1):
        rm = re.search(r"\[\s*Route\s*\(\s*\"([^\"]*)\"", text)
        if rm and not class_route:
            class_route = rm.group(1)
        hm = _CS_HTTP_ATTR_RE.search(text)
        if not hm:
            continue
        for k in range(n, min(n + 5, len(lines))):
            mm = _CS_METHOD_RE.match(lines[k])
            if mm:
                start, end = _block_range(content, k + 1)
                params = lines[k][lines[k].find("(") + 1:]
                out.append({
                    "verb": hm.group(1).upper(), "route": f"{class_route}/{hm.group(2) or ''}".strip("/"),
                    "method": mm.group(1), "range": (start, end),
                    "param_types": re.findall(r"(?:\[\w+\]\s*)?([A-Z]\w+)\s+\w+\s*[,)]", params),
                })
                break
    return out


def _route_key(url: str) -> str:
    """URL の最後の固定セグメント(例: /api/orders/${id}/cancel → cancel, /api/orders/{id} → orders)。"""
    segs = [s for s in re.split(r"[/?]", url) if s and not re.search(r"[${}:]", s)]
    return segs[-1].lower() if segs else ""


# ---------------------------------------------------------------------------
# 操作(Scenario)ごとにまとめる
# ---------------------------------------------------------------------------

def _lines_text(content: str, rng: tuple[int, int], limit: int = 60) -> str:
    lines = content.splitlines()[rng[0] - 1: rng[1]]
    return "\n".join(f"[L{rng[0] + i}] {t}" for i, t in enumerate(lines[:limit]))


def extract_scenarios(files: list[FileDiff], show_file: Callable[[str], str]) -> list[Scenario]:
    """差分から操作ごとの更新前チェック・更新後の表示を抽出する。

    show_file(path) は feature 側のファイル全文を返す関数。
    """
    by_path = {f.path: f for f in files if f.status != "deleted" and f.hunks}
    evidence: dict[str, list[Evidence]] = {}
    triggers: list[Trigger] = []
    for f in by_path.values():
        if f.language == "typescript":
            evidence[f.path] = _ts_evidence(f)
        elif f.language == "html":
            ev, tr = _html_evidence(f)
            evidence[f.path] = ev
            triggers += tr
        elif f.language == "csharp":
            evidence[f.path] = _cs_evidence(f)
    if not any(evidence.values()) and not triggers:
        return []

    contents: dict[str, str] = {}

    def content(path: str) -> str:
        if path not in contents:
            contents[path] = show_file(path) or ""
        return contents[path]

    # C# の全エンドポイント・メソッド(差分に含まれるファイルのみ)
    cs_files = [p for p, f in by_path.items() if f.language == "csharp"]
    endpoints = [dict(ep, file=p) for p in cs_files for ep in _cs_endpoints(content(p))]
    cs_methods = {p: _methods(content(p), "csharp") for p in cs_files}
    ts_files = [p for p, f in by_path.items() if f.language == "typescript"]
    ts_methods = {p: _methods(content(p), "typescript") for p in ts_files}

    used: set[tuple[str, int]] = set()
    scenarios: list[Scenario] = []

    def take(sc: Scenario, path: str, rng: tuple[int, int]) -> None:
        for e in evidence.get(path, []):
            if rng[0] <= e.line <= rng[1] and (path, e.line, e.check) not in used:
                used.add((path, e.line, e.check))
                sc.evidences.append(e)

    seen_handlers: set[tuple[str, str]] = set()
    for t in triggers:
        if (t.file, t.handler) in seen_handlers:
            continue
        seen_handlers.add((t.file, t.handler))
        sc = Scenario(key=f"{t.file}#{t.handler}", title=f"「{t.label}」ボタン",
                      trigger=f"{PurePosixPath(t.file).name} L{t.line} → {t.handler}()")
        take(sc, t.file, (t.line, t.line))                # ボタン自体の [disabled]
        sc.code_context.append(f"// {t.file}\n{_lines_text(content(t.file), (max(1, t.line - 2), t.line + 2))}")

        # 同じフォルダの .ts(コンポーネント)からハンドラーを探す
        ts_path = re.sub(r"\.html$", ".ts", t.file)
        candidates = [ts_path] + [p for p in ts_files if p != ts_path]
        chain: list[str] = []
        for p in candidates:
            methods = ts_methods.get(p) or (_methods(content(p), "typescript") if p == ts_path else {})
            if t.handler not in methods:
                continue
            rng = methods[t.handler]
            take(sc, p, rng)
            sc.code_context.append(f"// {p}\n{_lines_text(content(p), rng)}")
            # ハンドラーから呼ばれる同じクラスのメソッド(validate() など)と HTTP 呼び出し
            calls = _ts_http_calls(content(p), *rng)
            for name in _ts_called_methods(content(p), *rng):
                if name in methods and name != t.handler:
                    take(sc, p, methods[name])
                    calls += _ts_http_calls(content(p), *methods[name])
                for sp in ts_files:          # サービス経由の HTTP 呼び出し
                    if sp != p and name in ts_methods.get(sp, {}):
                        calls += _ts_http_calls(content(sp), *ts_methods[sp][name])
            for verb, url in calls:
                chain.append(f"{verb} {url}")
                key = _route_key(url)
                for ep in endpoints:
                    if ep["verb"] == verb and key and (key == _route_key(ep["route"]) or key == ep["method"].lower()):
                        chain.append(f"{ep['method']}()")
                        take(sc, ep["file"], ep["range"])
                        sc.code_context.append(f"// {ep['file']}\n{_lines_text(content(ep['file']), ep['range'])}")
                        _take_cs_related(sc, ep, cs_methods, content, take)
            break
        if chain:
            sc.trigger += " → " + " → ".join(dict.fromkeys(chain))
        sc._trigger = t  # type: ignore[attr-defined]
        scenarios.append(sc)

    _attach_screen_prechecks(scenarios, evidence, used)
    scenarios = [sc for sc in scenarios if sc.evidences]

    # どの操作にも属さない根拠は、ファイル単位でまとめる
    for path, evs in evidence.items():
        rest = [e for e in evs if (path, e.line, e.check) not in used]
        if not rest:
            continue
        name = PurePosixPath(path).name
        title = "画面表示の変更" if all(e.kind == VIEW for e in rest) else "その他の処理の変更"
        sc = Scenario(key=path, title=f"{title}({name})", trigger=path, evidences=rest)
        lines = sorted({e.line for e in rest})
        sc.code_context.append(f"// {path}\n" + "\n".join(
            f"[L{e.line}] {e.code}" for e in sorted(rest, key=lambda e: e.line)))
        scenarios.append(sc)

    layer = {"html": 0, "ts": 1, "cs": 2}
    for sc in scenarios:
        sc.evidences.sort(key=lambda e: (e.kind != PRE, layer.get(e.file.rsplit(".", 1)[-1], 3), e.file, e.line))
        seen: set[str] = set()
        sc.evidences = [e for e in sc.evidences if not (e.check in seen or seen.add(e.check))]
        sc.build_items_from_evidence()
    return scenarios


_SUBMIT_LIKE_RE = re.compile(r"save|update|regist|submit|create|edit|entry|apply|confirm|登録|更新|保存", re.I)


def _attach_screen_prechecks(scenarios: list[Scenario], evidence: dict[str, list[Evidence]],
                             used: set) -> None:
    """メソッド外の根拠を、同じ画面のボタンの操作に寄せる。

    更新前チェック(Validators の定義・HTML のエラー表示):
      HTML: その根拠より後ろにある最初のボタン(通常はフォームの登録/更新ボタン)
      TS  : 登録/更新系の名前のハンドラー(なければ最初のボタン)
    表示の変更(HTML の {{ }} / @if / [class.x]):
      登録/更新系のボタンがあれば、その操作の「更新後の表示」として確認する
    """
    by_stem: dict[str, list[Scenario]] = {}
    for sc in scenarios:
        t = getattr(sc, "_trigger", None)
        if t:
            by_stem.setdefault(re.sub(r"\.(html|ts)$", "", t.file), []).append(sc)
    for path, evs in evidence.items():
        cands = by_stem.get(re.sub(r"\.(html|ts)$", "", path))
        if not cands:
            continue
        submit = next((sc for sc in cands if _SUBMIT_LIKE_RE.search(sc._trigger.handler + sc._trigger.label)), None)
        for e in evs:
            if e.kind not in (PRE, VIEW) or (path, e.line, e.check) in used:
                continue
            if e.kind == VIEW:
                if submit is None:
                    continue  # 更新系のボタンがない画面は「画面表示の変更」として別にまとめる
                target = submit
            elif path.endswith(".html"):
                after = sorted((sc for sc in cands if sc._trigger.line >= e.line), key=lambda sc: sc._trigger.line)
                target = after[0] if after else cands[-1]
            else:
                target = next((sc for sc in cands if _SUBMIT_LIKE_RE.search(sc._trigger.handler + sc._trigger.label)),
                              cands[0])
            used.add((path, e.line, e.check))
            target.evidences.append(e)


def _take_cs_related(sc: Scenario, ep: dict, cs_methods: dict, content, take) -> None:
    """コントローラーから呼ばれるサービスのメソッド・DTO クラスの根拠も同じ操作に含める。"""
    body = "\n".join(content(ep["file"]).splitlines()[ep["range"][0] - 1: ep["range"][1]])
    called = set(re.findall(r"\.(\w+)\s*\(", body)) - {ep["method"]}
    for path, methods in cs_methods.items():
        for name in called:
            if name in methods and not (path == ep["file"] and name == ep["method"]):
                take(sc, path, methods[name])
                sc.code_context.append(f"// {path}\n{_lines_text(content(path), methods[name])}")
        text = content(path)
        for t in ep.get("param_types", []):
            cm = re.search(rf"^\s*(?:public\s+)?(?:sealed\s+)?(?:class|record)\s+{re.escape(t)}\b", text, re.M)
            if cm:
                start = text[: cm.start()].count("\n") + 1
                rng = _block_range(text, start)
                take(sc, path, rng)
