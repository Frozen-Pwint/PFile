"""チェックリスト関連のデータ構造。"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Optional

SEVERITY_ORDER = {"high": 0, "medium": 1, "low": 2}
SEVERITY_LABEL = {"high": "高", "medium": "中", "low": "低"}


def normalize_severity(value: str) -> str:
    v = (value or "").strip().lower()
    mapping = {"高": "high", "中": "medium", "低": "low", "critical": "high", "major": "high",
               "minor": "low", "info": "low", "warning": "medium"}
    v = mapping.get(v, v)
    return v if v in SEVERITY_ORDER else "medium"


@dataclass
class ChecklistItem:
    check: str                      # チェック項目(「〜しているか」形式)
    category: str                   # セキュリティ / 性能 / 保守性 / 業務ロジック ...
    severity: str = "medium"        # high | medium | low
    reason: str = ""                # なぜ確認が必要か
    file: Optional[str] = None      # None = PR 全体に対する共通項目
    lines: list[int] = field(default_factory=list)  # feature 側の行番号
    source: str = "rule"            # rule | ai | common
    rule_id: str = ""
    idx: int = -1                   # Markdown 上の並び順(画面でのチェック状態を Markdown に反映するため)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ChecklistResult:
    meta: dict
    summary: str
    common_items: list[ChecklistItem]
    file_items: dict[str, list[ChecklistItem]]
    test_items: list[ChecklistItem]
    files: list[dict]
    commits: list[dict]
    warnings: list[str]
    scenarios: list = field(default_factory=list)   # behavior.Scenario: 操作ごとの更新前チェック・更新後の表示
    markdown: str = ""
    file_name: str = ""

    def to_dict(self) -> dict:
        return {
            "meta": self.meta,
            "summary": self.summary,
            "common_items": [i.to_dict() for i in self.common_items],
            "file_items": {k: [i.to_dict() for i in v] for k, v in self.file_items.items()},
            "test_items": [i.to_dict() for i in self.test_items],
            "files": self.files,
            "commits": self.commits,
            "warnings": self.warnings,
            "scenarios": [s.to_dict() for s in self.scenarios],
            "markdown": self.markdown,
            "file_name": self.file_name,
        }
