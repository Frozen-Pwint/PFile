"""
社内 Ollama の GPT モデルで、差分からチェック項目を生成する。

- ファイル単位で差分を送り、そのファイル固有の確認項目を JSON で返してもらう
- 大きい差分はハンク単位で分割(LLM_MAX_CHARS_PER_CALL を超えないように)
- 最後に全体要約とテスト観点を 1 回で生成する
"""
from __future__ import annotations

from typing import Any, Callable, Optional

from .config import settings
from .git_diff import FileDiff
from .models import ChecklistItem, normalize_severity
from .ollama_client import OllamaClient, OllamaError

LANG_LABEL = {
    "csharp": "C# (.NET / ERP バックエンド)",
    "typescript": "TypeScript (Angular)",
    "typescript-test": "TypeScript テスト (Angular / Jasmine)",
    "html": "HTML (Angular テンプレート)",
    "css": "CSS/SCSS (Angular)",
    "sql": "SQL",
    "json": "JSON 設定",
    "config": "設定ファイル",
    "msbuild": "C# プロジェクトファイル",
}

FILE_SYSTEM_PROMPT = """あなたは ERP システム(C# / ASP.NET バックエンド、Angular フロントエンド)の
シニアレビュアーです。プルリクエストの差分を読み、レビュアーと実装者が
マージ前に確認すべき「チェックリスト項目」を日本語で作成します。

ルール:
- 差分の追加・変更内容から具体的に言える項目だけを書く。一般論や差分と無関係な項目は書かない。
- 各項目は「〜しているか」「〜になっていないか」の確認形式の 1 文にする。
- クラス名・メソッド名・項目名など、差分中の具体的な名前を含める。
- ERP の観点(金額・数量・端数処理、締め/日付、在庫・伝票の整合性、権限、排他制御、
  大量データ時の性能、既存機能への影響)を重視する。
- 「既に検出済みの項目」と同じ内容は書かない。
- 該当行番号は差分中の [Lxx] の番号(feature 側の行番号)を使う。不明なら null。
- 確認不要なら items は空配列にする。

次の JSON だけを出力すること:
{"summary": "このファイルの変更内容の要約(1〜2文)",
 "items": [{"check": "確認項目", "category": "セキュリティ|性能|業務ロジック|データ整合性|エラー処理|影響範囲|保守性|UI|テスト|その他",
            "severity": "high|medium|low", "reason": "確認が必要な理由(1文)", "line": 行番号またはnull}]}"""

SUMMARY_SYSTEM_PROMPT = """あなたは ERP システムのテックリードです。プルリクエストの変更ファイルごとの要約を読み、
(1) PR 全体の変更概要 と (2) 動作確認で実施すべきテスト観点 を日本語で作成します。

テスト観点は、正常系・異常系・境界値・権限・既存機能のデグレ確認などから、
この PR の変更に具体的に関係するものだけを 3〜10 個挙げる。各項目は「〜を確認する」形式。

次の JSON だけを出力すること:
{"summary": "PR 全体の変更概要(3〜5文)",
 "tests": [{"check": "テスト観点", "severity": "high|medium|low", "reason": "理由(1文)"}]}"""


def format_diff_for_llm(fd: FileDiff, hunks=None) -> str:
    """差分を LLM 向けに整形する。追加/文脈行には feature 側の行番号 [Lxx] を付ける。"""
    out = []
    for h in (hunks if hunks is not None else fd.hunks):
        out.append(h.header)
        for l in h.lines:
            if l.kind == "add":
                out.append(f"[L{l.new_lineno}] + {l.content}")
            elif l.kind == "del":
                out.append(f"       - {l.content}")
            else:
                out.append(f"[L{l.new_lineno}]   {l.content}")
    return "\n".join(out)


def split_hunks(fd: FileDiff, max_chars: int) -> list[list]:
    """ハンクを max_chars 以内のグループに分ける(1 ハンクが超える場合は単独)。"""
    groups: list[list] = []
    current: list = []
    size = 0
    for h in fd.hunks:
        h_size = len(format_diff_for_llm(fd, [h]))
        if current and size + h_size > max_chars:
            groups.append(current)
            current, size = [], 0
        current.append(h)
        size += h_size
    if current:
        groups.append(current)
    return groups


def _to_items(raw_items: Any, file_path: Optional[str], limit: int, source: str = "ai",
              default_category: str = "その他") -> list[ChecklistItem]:
    items: list[ChecklistItem] = []
    if not isinstance(raw_items, list):
        return items
    for r in raw_items:
        if not isinstance(r, dict):
            continue
        check = str(r.get("check") or "").strip()
        if not check:
            continue
        line = r.get("line")
        lines = [int(line)] if isinstance(line, (int, float)) or (isinstance(line, str) and line.isdigit()) else []
        items.append(ChecklistItem(
            check=check,
            category=str(r.get("category") or default_category).strip(),
            severity=normalize_severity(str(r.get("severity") or "medium")),
            reason=str(r.get("reason") or "").strip(),
            file=file_path,
            lines=lines,
            source=source,
        ))
        if len(items) >= limit:
            break
    return items


def review_file(client: OllamaClient, fd: FileDiff, already: list[ChecklistItem],
                issue_context: str = "") -> tuple[str, list[ChecklistItem], list[str]]:
    """1 ファイル分の AI チェック項目を生成。戻り値: (要約, 項目, 警告)"""
    warnings: list[str] = []
    groups = split_hunks(fd, settings.LLM_MAX_CHARS_PER_CALL)
    if len(groups) > settings.LLM_MAX_CHUNKS_PER_FILE:
        warnings.append(
            f"{fd.path}: 差分が大きいため先頭 {settings.LLM_MAX_CHUNKS_PER_FILE}/{len(groups)} ブロックのみ AI レビューしました。")
        groups = groups[: settings.LLM_MAX_CHUNKS_PER_FILE]

    known = "\n".join(f"- {i.check}" for i in already) or "(なし)"
    summaries: list[str] = []
    items: list[ChecklistItem] = []
    for idx, group in enumerate(groups, 1):
        part = f"(分割 {idx}/{len(groups)})" if len(groups) > 1 else ""
        user = (
            f"ファイル: {fd.path} {part}\n"
            f"種別: {LANG_LABEL.get(fd.language, fd.language)} / 状態: {fd.status}\n"
            + (f"Issue/PR の内容: {issue_context}\n" if issue_context else "")
            + f"\n既に検出済みの項目(重複させない):\n{known}\n\n"
            f"差分:\n```diff\n{format_diff_for_llm(fd, group)}\n```"
        )
        data = client.chat_json(FILE_SYSTEM_PROMPT, user)
        if isinstance(data, dict):
            if data.get("summary"):
                summaries.append(str(data["summary"]).strip())
            items.extend(_to_items(data.get("items"), fd.path, settings.LLM_MAX_ITEMS_PER_FILE))
        elif isinstance(data, list):
            items.extend(_to_items(data, fd.path, settings.LLM_MAX_ITEMS_PER_FILE))

    # 分割した場合の上限と、同一文言の重複除去
    seen, unique = set(), []
    for i in items:
        key = i.check.replace(" ", "")
        if key not in seen:
            seen.add(key)
            unique.append(i)
    return " ".join(summaries), unique[: settings.LLM_MAX_ITEMS_PER_FILE], warnings


def summarize_pr(client: OllamaClient, base: str, feature: str, file_summaries: dict[str, str],
                 commits: list[dict], issue_context: str = "") -> tuple[str, list[ChecklistItem]]:
    lines = [f"マージ先: {base} / feature: {feature}"]
    if issue_context:
        lines.append(f"Issue/PR の内容: {issue_context}")
    if commits:
        lines.append("コミット:")
        lines += [f"- {c['subject']}" for c in commits[:30]]
    lines.append("\n変更ファイルごとの要約:")
    lines += [f"- {p}: {s or '(要約なし)'}" for p, s in file_summaries.items()]
    data = client.chat_json(SUMMARY_SYSTEM_PROMPT, "\n".join(lines))
    if not isinstance(data, dict):
        return "", []
    tests = _to_items(data.get("tests"), None, 12, source="ai", default_category="テスト")
    for t in tests:
        t.category = "テスト"
    return str(data.get("summary") or "").strip(), tests


# ---------------------------------------------------------------------------
# 操作ごとの「更新前チェック」「更新後の表示」(behavior.py の結果を AI で具体化)
# ---------------------------------------------------------------------------

SCENARIO_SYSTEM_PROMPT = """あなたは ERP システム(Angular + C#)のテストリーダーです。
プルリクエストで追加・変更された「画面の操作」(例: 更新ボタン)について、
動作確認で実際に試すチェック項目を日本語で作成します。

入力として、操作の流れ・関連コード・ルールで検出した根拠一覧が与えられます。

作成する項目:
- 更新前チェック: 操作を実行する前に行われる入力チェック・状態チェック・確認ダイアログ・権限/排他チェック。
  「どんな値/状態のとき」「どのメッセージが出て」「更新されないこと」を具体的に書く。
  境界値(最小値・最大値・桁数ちょうど)は OK/NG の両方が分かるように書く。
  画面側とサーバー側で同じチェックがある場合は 1 項目にまとめ、両方で止まることを確認する書き方にする。
- 更新後の表示: 正常に更新されたあと画面で何が変わるか(メッセージ、表示される値、ステータス表示、
  ボタンの活性/非活性、一覧の再読込、画面遷移、更新日時/更新者など)。
- 表示の変更: 差分で追加/変更された表示項目(書式、条件付き表示、色やスタイルの切り替え)。
- 更新失敗時: エラー時に画面がどうなるか(メッセージ、入力内容が残るか、再操作できるか)。

ルール:
- コードと根拠に書かれている内容だけを根拠にする。推測で仕様を作らない。
- 各項目には根拠の file(ファイル名)と line(行番号)を必ず付ける。
- 根拠一覧の項目は、まとめてもよいが必ずどれかの項目に反映する。
- 1 項目 1 確認。「〜こと」で終わる文にする。

次の JSON だけを出力すること:
{"title": "操作の名前(例: 受注編集画面の「更新」ボタン)",
 "items": [{"category": "更新前チェック|更新後の表示|表示の変更|更新失敗時",
            "check": "確認項目", "severity": "high|medium|low", "file": "ファイル名", "line": 行番号}]}"""

SCENARIO_CATEGORIES = ("更新前チェック", "更新後の表示", "表示の変更", "更新失敗時")


def refine_scenario(client: OllamaClient, sc, issue_context: str = "") -> None:
    """Scenario の pre_checks / post_effects を AI で具体的なテスト項目に書き直す(その場で更新)。

    AI が触れなかったルール検出の根拠(ファイル名 + 行番号で判定)は、漏れ防止のため残す。
    """
    evid = "\n".join(
        f"- [{e.kind}] {e.check} ({e.file.rsplit('/', 1)[-1]} L{e.line}: {e.code[:120]})" for e in sc.evidences)
    code = "\n\n".join(sc.code_context)
    if len(code) > settings.LLM_MAX_CHARS_PER_CALL:
        code = code[: settings.LLM_MAX_CHARS_PER_CALL] + "\n…(以下省略)"
    user = (
        f"操作: {sc.title}\n流れ: {sc.trigger}\n"
        + (f"Issue/PR の内容: {issue_context}\n" if issue_context else "")
        + f"\nルールで検出した根拠:\n{evid}\n\n関連コード(feature ブランチ):\n```\n{code}\n```"
    )
    data = client.chat_json(SCENARIO_SYSTEM_PROMPT, user)
    if not isinstance(data, dict) or not isinstance(data.get("items"), list):
        return

    by_name = {e.file.rsplit("/", 1)[-1]: e.file for e in sc.evidences}
    pre: list[ChecklistItem] = []
    post: list[ChecklistItem] = []
    covered: set[tuple[str, int]] = set()
    for r in data["items"][:30]:
        if not isinstance(r, dict) or not str(r.get("check") or "").strip():
            continue
        cat = str(r.get("category") or "").strip()
        if cat not in SCENARIO_CATEGORIES:
            cat = "更新前チェック" if "前" in cat else "更新後の表示"
        fname = str(r.get("file") or "").rsplit("/", 1)[-1]
        line = r.get("line")
        lines = [int(line)] if isinstance(line, (int, float)) or (isinstance(line, str) and line.isdigit()) else []
        if fname and lines:
            covered.add((fname, lines[0]))
        item = ChecklistItem(
            check=str(r["check"]).strip(), category=cat,
            severity=normalize_severity(str(r.get("severity") or "medium")),
            reason="", file=by_name.get(fname, fname or None), lines=lines, source="ai", rule_id="BEHAVIOR",
        )
        (pre if cat == "更新前チェック" else post).append(item)
    if not pre and not post:
        return

    # AI が触れなかったルールの根拠は残す(漏れ防止)
    for i in sc.pre_checks:
        if (i.file.rsplit("/", 1)[-1], i.lines[0] if i.lines else -1) not in covered:
            pre.append(i)
    for i in sc.post_effects:
        if (i.file.rsplit("/", 1)[-1], i.lines[0] if i.lines else -1) not in covered:
            post.append(i)
    if str(data.get("title") or "").strip():
        sc.title = str(data["title"]).strip()
    sc.pre_checks, sc.post_effects = pre, post
