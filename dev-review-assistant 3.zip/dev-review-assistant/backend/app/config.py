"""
アプリ設定モジュール。

外部ライブラリ(python-dotenv等)に依存せず、環境変数 + 簡易 .env ローダーで
設定を読み込む。社内ネットワーク(証明書による制限)で pip が使えない環境でも
動くよう、バックエンド全体を標準ライブラリのみで構成している。
"""
from __future__ import annotations

import os
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = BACKEND_DIR.parent


def _load_dotenv(path: Path) -> None:
    """簡易 .env ローダー。既に環境変数に設定されている値は上書きしない。"""
    if not path.exists():
        return
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


_load_dotenv(BACKEND_DIR / ".env")


def _get_bool(name: str, default: bool) -> bool:
    val = os.environ.get(name)
    if val is None:
        return default
    return val.strip().lower() in ("1", "true", "yes", "on")


def _get_list(name: str) -> list[str]:
    val = os.environ.get(name, "")
    return [v.strip() for v in val.split(";") if v.strip()]


class Settings:
    # --- 社内 Ollama 接続設定 ---
    OLLAMA_BASE_URL: str = os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434")
    OLLAMA_CHAT_MODEL: str = os.environ.get("OLLAMA_CHAT_MODEL", "gpt-oss:20b")
    OLLAMA_EMBED_MODEL: str = os.environ.get("OLLAMA_EMBED_MODEL", "nomic-embed-text")
    OLLAMA_API_KEY: str = os.environ.get("OLLAMA_API_KEY", "")  # 社内ゲートウェイ経由で必要な場合のみ
    OLLAMA_TIMEOUT_SEC: float = float(os.environ.get("OLLAMA_TIMEOUT_SEC", "300"))
    OLLAMA_TEMPERATURE: float = float(os.environ.get("OLLAMA_TEMPERATURE", "0.1"))
    OLLAMA_VERIFY_TLS: bool = _get_bool("OLLAMA_VERIFY_TLS", True)
    OLLAMA_CA_BUNDLE: str = os.environ.get("OLLAMA_CA_BUNDLE", "")  # 社内CA証明書(.pem/.crt)

    # --- LLM によるチェックリスト生成 ---
    LLM_MAX_CHARS_PER_CALL: int = int(os.environ.get("LLM_MAX_CHARS_PER_CALL", "12000"))
    LLM_MAX_CHUNKS_PER_FILE: int = int(os.environ.get("LLM_MAX_CHUNKS_PER_FILE", "4"))
    LLM_MAX_ITEMS_PER_FILE: int = int(os.environ.get("LLM_MAX_ITEMS_PER_FILE", "8"))
    LLM_CONCURRENCY: int = int(os.environ.get("LLM_CONCURRENCY", "2"))
    # 操作ごとの確認項目(更新前チェック・更新後の表示)を AI で具体化する最大の操作数
    LLM_MAX_SCENARIOS: int = int(os.environ.get("LLM_MAX_SCENARIOS", "8"))

    # --- Git / レビュー対象リポジトリ ---
    DEFAULT_REPO_PATH: str = os.environ.get("DEFAULT_REPO_PATH", "")
    DEFAULT_BASE_BRANCH: str = os.environ.get("DEFAULT_BASE_BRANCH", "origin/master")
    # 指定可能なリポジトリのルートを制限する場合(; 区切り)。空なら制限なし。
    ALLOWED_REPO_ROOTS: list[str] = _get_list("ALLOWED_REPO_ROOTS")
    # チェックリスト・AIレビューの対象外にするファイル(glob, ; 区切り)
    EXCLUDE_PATTERNS: list[str] = _get_list("EXCLUDE_PATTERNS") or [
        "package-lock.json", "yarn.lock", "pnpm-lock.yaml", "*.min.js", "*.min.css",
        "*.map", "dist/*", "bin/*", "obj/*", "*.Designer.cs", "*.png", "*.jpg",
        "*.gif", "*.ico", "*.svg", "*.woff", "*.woff2", "*.dll", "*.pdb",
    ]

    # --- 出力 ---
    CHECKLIST_OUTPUT_DIR: str = os.environ.get(
        "CHECKLIST_OUTPUT_DIR", str(BACKEND_DIR / "output" / "checklists")
    )

    # --- ベクトルDB(RAG。SQLite + numpy の自前実装) ---
    VECTOR_DB_PATH: str = os.environ.get(
        "VECTOR_DB_PATH", str(BACKEND_DIR / "data" / "vector_store.db")
    )
    RAG_CHUNK_SIZE: int = int(os.environ.get("RAG_CHUNK_SIZE", "800"))
    RAG_CHUNK_OVERLAP: int = int(os.environ.get("RAG_CHUNK_OVERLAP", "120"))
    RAG_TOP_K: int = int(os.environ.get("RAG_TOP_K", "5"))

    # --- サーバー ---
    HOST: str = os.environ.get("HOST", "0.0.0.0")
    PORT: int = int(os.environ.get("PORT", "8000"))
    # Angular の開発サーバー(ng serve)から呼ぶ場合の CORS 許可オリジン
    CORS_ORIGINS: list[str] = _get_list("CORS_ORIGINS") or ["http://localhost:4200"]
    # ng build の出力先。存在すれば同じポートで画面も配信する
    STATIC_DIR: str = os.environ.get(
        "STATIC_DIR", str(PROJECT_ROOT / "frontend" / "dist" / "checklist-ui" / "browser")
    )


settings = Settings()

Path(settings.CHECKLIST_OUTPUT_DIR).mkdir(parents=True, exist_ok=True)
Path(settings.VECTOR_DB_PATH).parent.mkdir(parents=True, exist_ok=True)
