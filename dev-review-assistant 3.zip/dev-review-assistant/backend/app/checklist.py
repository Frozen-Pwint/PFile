"""
PR チェックリスト生成の本体。

  1. (任意) git fetch で origin を最新化
  2. マージ先ブランチ(例: origin/master)...feature ブランチ の差分を取得
  3. ルールベースでチェック項目を抽出
     + 操作ごと(例: 更新ボタン)の「更新前チェック」「更新後の表示」を抽出(behavior.py)
  4. 社内 Ollama の GPT でファイルごとのチェック項目・操作ごとの確認項目・全体要約・テスト観点を生成
  5. Markdown にまとめて保存
"""
from __future__ import annotations

import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional

from . import git_diff as g
from .config import settings
from .behavior import FAIL, PRE, VIEW, extract_scenarios
from .llm_checklist import refine_scenario, review_file, summarize_pr
from .models import SEVERITY_LABEL, SEVERITY_ORDER, ChecklistItem, ChecklistResult
from .ollama_client import OllamaClient, OllamaError
from .rules import analyze_file, common_items, is_excluded

ProgressFn = Callable[[str, int, int, str], None]

SEVERITY_ICON = {"high": "🔴", "medium": "🟡", "low": "🟢"}
STATUS_LABEL = {"added": "追加", "modified": "変更", "deleted": "削除", "renamed": "名前変更", "copied": "コピー"}
LANG_SHORT = {"csharp": "C#", "typescript": "TypeScript", "typescript-test": "テスト(TS)", "html": "HTML",
              "css": "CSS", "sql": "SQL", "json": "JSON", "config": "設定", "msbuild": "csproj", "other": "その他"}


def _noop(*_args) -> None:
    pass


def _sort_items(items: list[ChecklistItem]) -> list[ChecklistItem]:
    return sorted(items, key=lambda i: (SEVERITY_ORDER.get(i.severity, 1), i.lines[0] if i.lines else 0))


def check_repo_allowed(repo_path: str) -> str:
    resolved = str(Path(repo_path).expanduser().resolve())
    if settings.ALLOWED_REPO_ROOTS:
        roots = [str(Path(r).expanduser().resolve()) for r in settings.ALLOWED_REPO_ROOTS]
        if not any(resolved == r or resolved.startswith(r.rstrip("/\\") + ("\\" if "\\" in r else "/")) for r in roots):
            raise g.GitCommandError(f"このリポジトリは許可されていません: {repo_path}")
    return resolved


def generate_checklist(
    repo_path: str,
    base: str,
    feature: str,
    *,
    issue: str = "",
    title: str = "",
    description: str = "",
    use_llm: bool = True,
    fetch: bool = False,
    progress: ProgressFn = _noop,
    client: Optional[OllamaClient] = None,
) -> ChecklistResult:
    repo_path = check_repo_allowed(repo_path)
    warnings: list[str] = []

    if fetch:
        progress("fetch", 0, 1, "origin から最新を取得しています")
        try:
            if not g.fetch_remote(repo_path, "origin"):
                warnings.append("origin リモートが設定されていないため fetch をスキップしました。")
        except g.GitCommandError as exc:
            warnings.append(f"git fetch に失敗したため、手元の状態で比較しました: {exc}")

    progress("diff", 0, 1, f"{base}...{feature} の差分を取得しています")
    all_files = g.get_full_diff(repo_path, base, feature)
    commits = [c.__dict__ for c in g.get_commits(repo_path, base, feature)]
    meta = {
        "repo": repo_path,
        "base": base,
        "feature": feature,
        "base_sha": g.short_sha(repo_path, base),
        "feature_sha": g.short_sha(repo_path, feature),
        "merge_base": g.merge_base(repo_path, base, feature),
        "issue": issue,
        "title": title,
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "model": None,
        "file_count": len(all_files),
        "additions": sum(f.additions for f in all_files),
        "deletions": sum(f.deletions for f in all_files),
        "commit_count": len(commits),
    }
    if not all_files:
        warnings.append("差分がありません。ブランチの指定(マージ先は origin/xxx 形式)を確認してください。")

    targets = [f for f in all_files if not is_excluded(f.path, settings.EXCLUDE_PATTERNS)]
    skipped = [f.path for f in all_files if f not in targets]
    if skipped:
        warnings.append(f"チェック対象外として {len(skipped)} ファイルを除外しました(ロックファイル・画像・ビルド成果物など)。")

    # --- ルールベース ---
    progress("rules", 0, 1, "ルールベースのチェックを実行しています")
    all_paths = {f.path for f in all_files}
    file_items: dict[str, list[ChecklistItem]] = {f.path: analyze_file(f, all_paths) for f in targets}
    common = common_items(targets)
    progress("rules", 0, 1, "操作ごとの更新前チェック・更新後の表示を抽出しています")
    try:
        scenarios = extract_scenarios(targets, lambda p: g.show_file(repo_path, feature, p))
    except Exception as exc:  # noqa: BLE001 - 抽出に失敗しても他の項目は作る
        scenarios = []
        warnings.append(f"操作ごとの確認項目の抽出に失敗しました({exc})")

    # --- AI(社内 Ollama) ---
    summary, test_items = "", []
    if use_llm and targets:
        client = client or OllamaClient()
        progress("ai", 0, 0, "社内 Ollama への接続を確認しています")
        try:
            OllamaClient(base_url=client.base_url, model=client.model, timeout=15).health()
        except OllamaError as exc:
            warnings.append(f"社内 Ollama に接続できないため、ルールベースの項目のみで作成しました({exc})")
            use_llm = False
    if use_llm and targets:
        meta["model"] = client.model
        issue_context = " / ".join(x for x in (f"#{issue}" if issue else "", title, description) if x)
        llm_targets = [f for f in targets if f.hunks and f.status != "deleted"]
        file_summaries: dict[str, str] = {f.path: "削除" for f in targets if f.status == "deleted"}
        ai_scenarios = scenarios[: settings.LLM_MAX_SCENARIOS]
        done = 0
        total = len(llm_targets) + len(ai_scenarios)
        progress("ai", 0, total, "AI レビューを開始します")
        llm_failed = False

        def known_for(path: str) -> list[ChecklistItem]:
            # ファイル別の AI レビューで、操作ごとの項目と重複させないため
            extra = [i for sc in scenarios for i in sc.pre_checks + sc.post_effects if i.file == path]
            return file_items.get(path, []) + extra

        with ThreadPoolExecutor(max_workers=max(1, settings.LLM_CONCURRENCY)) as pool:
            futures = {
                pool.submit(review_file, client, f, known_for(f.path), issue_context): f
                for f in llm_targets
            }
            sc_futures = {pool.submit(refine_scenario, client, sc, issue_context): sc for sc in ai_scenarios}
            for fut in as_completed(list(futures) + list(sc_futures)):
                done += 1
                if fut in sc_futures:
                    sc = sc_futures[fut]
                    try:
                        fut.result()
                    except OllamaError as exc:
                        warnings.append(f"{sc.title}: 操作ごとの確認項目の AI 作成に失敗しました(ルールの項目のみ)({exc})")
                    progress("ai", done, total, f"AI: 操作ごとの確認項目 {sc.title}")
                    continue
                f = futures[fut]
                try:
                    s, items, w = fut.result()
                    file_summaries[f.path] = s
                    file_items.setdefault(f.path, []).extend(items)
                    warnings.extend(w)
                except OllamaError as exc:
                    llm_failed = True
                    warnings.append(f"{f.path}: AI レビューに失敗しました({exc})")
                progress("ai", done, total, f"AI レビュー: {f.path}")
        if llm_failed and not any(i.source == "ai" for v in file_items.values() for i in v):
            warnings[:] = [w for w in warnings if "AI レビューに失敗しました" not in w and "AI 作成に失敗" not in w]
            warnings.append("AI レビューがすべて失敗したため、ルールベースの項目のみで作成しました。"
                            "モデル名(OLLAMA_CHAT_MODEL)とタイムアウト設定を確認してください。")
            meta["model"] = None
        else:
            progress("summary", 0, 1, "PR 全体の要約とテスト観点を作成しています")
            try:
                summary, test_items = summarize_pr(client, base, feature, file_summaries, commits, issue_context)
            except OllamaError as exc:
                warnings.append(f"全体要約の作成に失敗しました({exc})")

    for path in list(file_items):
        file_items[path] = _sort_items(file_items[path])

    files_info = [
        {"path": f.path, "old_path": f.old_path, "status": f.status, "language": f.language,
         "additions": f.additions, "deletions": f.deletions, "excluded": f.path in skipped,
         "item_count": len(file_items.get(f.path, []))}
        for f in all_files
    ]
    result = ChecklistResult(meta=meta, summary=summary, common_items=common, file_items=file_items,
                             test_items=test_items, files=files_info, commits=commits, warnings=warnings,
                             scenarios=scenarios)
    progress("render", 0, 1, "Markdown を作成しています")
    result.markdown = render_markdown(result)
    result.file_name = save_markdown(result)
    progress("done", 1, 1, "完了しました")
    return result


# ---------------------------------------------------------------------------
# Markdown
# ---------------------------------------------------------------------------

def _md_escape_cell(text: str) -> str:
    return (text or "").replace("|", "\\|").replace("\n", " ")


def _item_line(i: ChecklistItem, counter: list[int], show_file: bool = False) -> list[str]:
    i.idx = counter[0]
    counter[0] += 1
    tag = f"{SEVERITY_ICON[i.severity]} **[{SEVERITY_LABEL[i.severity]}]**"
    loc = ""
    if i.lines:
        where = f"{Path(i.file).name} " if show_file and i.file else ""
        loc = f" ({where}" + ", ".join(f"L{n}" for n in i.lines[:6]) + (" …" if len(i.lines) > 6 else "") + ")"
    src = " `AI`" if i.source == "ai" else ""
    out = [f"- [ ] {tag} {i.check}{loc}{src}"]
    if show_file:
        if i.reason:
            out.append(f"  - {i.reason}")
        return out
    meta = f"{i.category}" + (f" ― {i.reason}" if i.reason else "")
    out.append(f"  - {meta}")
    return out


def render_markdown(r: ChecklistResult) -> str:
    m = r.meta
    scenario_items = [i for sc in r.scenarios for i in sc.pre_checks + sc.post_effects]
    all_items = r.common_items + scenario_items + [i for v in r.file_items.values() for i in v] + r.test_items
    count = {s: sum(1 for i in all_items if i.severity == s) for s in ("high", "medium", "low")}
    heading = f"PR チェックリスト: {m['feature']} → {m['base']}"
    if m.get("issue"):
        heading = f"PR チェックリスト: #{m['issue']} {m.get('title') or ''}".rstrip()

    md: list[str] = [f"# {heading}", ""]
    md += [
        "| 項目 | 内容 |", "|---|---|",
        *( [f"| Issue | #{_md_escape_cell(m['issue'])} {_md_escape_cell(m.get('title') or '')} |"] if m.get("issue") else [] ),
        f"| マージ先 (base) | `{m['base']}` ({m['base_sha']}) |",
        f"| feature ブランチ | `{m['feature']}` ({m['feature_sha']}) |",
        f"| マージベース | {m['merge_base'] or '-'} |",
        f"| コミット数 | {m['commit_count']} |",
        f"| 変更ファイル | {m['file_count']} ファイル (+{m['additions']} / -{m['deletions']}) |",
        f"| 生成日時 | {m['generated_at']} |",
        f"| AI モデル | {m['model'] or '未使用(ルールベースのみ)'} |",
        "",
        f"**チェック項目: {len(all_items)} 件** ― {SEVERITY_ICON['high']} 高 {count['high']} / "
        f"{SEVERITY_ICON['medium']} 中 {count['medium']} / {SEVERITY_ICON['low']} 低 {count['low']}",
        "",
    ]
    if r.warnings:
        md += ["> [!NOTE]"] + [f"> - {w}" for w in r.warnings] + [""]
    if r.summary:
        md += ["## 変更概要", "", r.summary, ""]

    counter = [0]
    r.common_items = _sort_items(r.common_items)
    md += ["## 1. 共通チェック", ""]
    for i in r.common_items:
        md += _item_line(i, counter)
    md.append("")

    if r.scenarios:
        md += ["## 2. 動作確認(操作ごとの更新前チェック・更新後の表示)", "",
               "差分に含まれる操作(ボタンなど)ごとに、実行前のチェック条件と実行後の画面の変化をまとめています。", ""]
        for sc in r.scenarios:
            md += [f"### {sc.title}", "", f"`{sc.trigger}`", ""]
            groups = [
                (PRE + "(条件を満たさないときは更新されないこと)", sc.pre_checks),
                ("更新後の表示(正常に更新されたとき)", [i for i in sc.post_effects if i.category not in (VIEW, FAIL)]),
                (VIEW, [i for i in sc.post_effects if i.category == VIEW]),
                (FAIL, [i for i in sc.post_effects if i.category == FAIL]),
            ]
            for label, items in groups:
                if not items:
                    continue
                md += [f"**{label}**", ""]
                for i in items:
                    md += _item_line(i, counter, show_file=True)
                md.append("")
    n_file = 3 if r.scenarios else 2
    md += [f"## {n_file}. ファイル別チェック", ""]
    files_with_items = [f for f in r.files if r.file_items.get(f["path"])]
    if not files_with_items:
        md += ["ファイル固有のチェック項目はありません。", ""]
    for f in files_with_items:
        st = STATUS_LABEL.get(f["status"], f["status"])
        md += [f"### `{f['path']}`", "",
               f"{LANG_SHORT.get(f['language'], f['language'])} / {st} / +{f['additions']} -{f['deletions']}", ""]
        for i in r.file_items[f["path"]]:
            md += _item_line(i, counter)
        md.append("")

    if r.test_items:
        md += [f"## {n_file + 1}. テスト観点", ""]
        for i in r.test_items:
            md += _item_line(i, counter)
        md.append("")

    md += ["## 変更ファイル一覧", "", "| # | ファイル | 種別 | 状態 | 追加 | 削除 | 項目数 |", "|---|---|---|---|---:|---:|---:|"]
    for n, f in enumerate(r.files, 1):
        st = STATUS_LABEL.get(f["status"], f["status"]) + ("(対象外)" if f.get("excluded") else "")
        md.append(f"| {n} | `{_md_escape_cell(f['path'])}` | {LANG_SHORT.get(f['language'], f['language'])} | {st} | "
                  f"{f['additions']} | {f['deletions']} | {f['item_count']} |")
    md.append("")

    if r.commits:
        md += ["## コミット", ""]
        md += [f"- `{c['sha']}` {c['subject']} ({c['author']}, {c['date']})" for c in r.commits]
        md.append("")

    md += ["---", "", "_このチェックリストは開発者サポートAIが自動生成しました。"
           "`AI` 付きの項目は社内 LLM による提案のため、内容を確認のうえ不要なら削除してください。_", ""]
    return "\n".join(md)


def _safe_name(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "-", s).strip("-")[:60] or "branch"


def save_markdown(r: ChecklistResult) -> str:
    m = r.meta
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    prefix = f"issue{_safe_name(m['issue'])}_" if m.get("issue") else ""
    name = f"checklist_{prefix}{_safe_name(m['feature'])}_{stamp}.md"
    path = Path(settings.CHECKLIST_OUTPUT_DIR) / name
    path.write_text(r.markdown, encoding="utf-8")
    return name


def list_saved_checklists(limit: int = 50) -> list[dict]:
    out_dir = Path(settings.CHECKLIST_OUTPUT_DIR)
    files = sorted(out_dir.glob("checklist_*.md"), key=lambda p: p.stat().st_mtime, reverse=True)[:limit]
    return [{"name": p.name, "size": p.stat().st_size,
             "modified": datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M")} for p in files]


def read_saved_checklist(name: str) -> str:
    safe = Path(name).name
    if safe != name or not safe.startswith("checklist_") or not safe.endswith(".md"):
        raise FileNotFoundError(name)
    path = Path(settings.CHECKLIST_OUTPUT_DIR) / safe
    if not path.is_file():
        raise FileNotFoundError(name)
    return path.read_text(encoding="utf-8")
