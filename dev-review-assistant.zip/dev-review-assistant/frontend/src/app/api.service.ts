import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { BranchList, ChecklistRequest, Health, Job, SavedChecklist } from './models';

/** Python バックエンド(/api)の呼び出し。開発時は proxy.conf.json で localhost:8000 に転送する。 */
@Injectable({ providedIn: 'root' })
export class ApiService {
  private readonly http = inject(HttpClient);
  private readonly base = '/api';

  health(): Observable<Health> {
    return this.http.get<Health>(`${this.base}/health`).pipe(catchError(toMessage));
  }

  branches(repo: string): Observable<BranchList> {
    const params = new HttpParams().set('repo', repo);
    return this.http.get<BranchList>(`${this.base}/branches`, { params }).pipe(catchError(toMessage));
  }

  fetch(repo: string): Observable<{ fetched: boolean }> {
    return this.http.post<{ fetched: boolean }>(`${this.base}/git/fetch`, { repo }).pipe(catchError(toMessage));
  }

  createChecklist(req: ChecklistRequest): Observable<{ job_id: string }> {
    return this.http.post<{ job_id: string }>(`${this.base}/checklists`, req).pipe(catchError(toMessage));
  }

  job(id: string): Observable<Job> {
    return this.http.get<Job>(`${this.base}/jobs/${id}`).pipe(catchError(toMessage));
  }

  savedList(): Observable<SavedChecklist[]> {
    return this.http.get<SavedChecklist[]>(`${this.base}/checklists`).pipe(catchError(toMessage));
  }

  savedMarkdown(name: string): Observable<string> {
    return this.http
      .get(`${this.base}/checklists/${encodeURIComponent(name)}`, { responseType: 'text' })
      .pipe(catchError(toMessage));
  }
}

/** バックエンドの {"error": "..."} を画面表示用のメッセージに変換する。 */
function toMessage(err: HttpErrorResponse): Observable<never> {
  let message = 'サーバーに接続できません。バックエンド(python -m app.server)が起動しているか確認してください。';
  if (err.status !== 0) {
    const body = err.error;
    if (body && typeof body === 'object' && 'error' in body) {
      message = String(body.error);
    } else if (typeof body === 'string' && body.includes('"error"')) {
      try {
        message = JSON.parse(body).error;
      } catch {
        message = `エラーが発生しました (HTTP ${err.status})`;
      }
    } else {
      message = `エラーが発生しました (HTTP ${err.status})`;
    }
  }
  return throwError(() => new Error(message));
}
