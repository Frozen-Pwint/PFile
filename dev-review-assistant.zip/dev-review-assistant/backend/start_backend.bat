@echo off
rem 開発者サポートAI バックエンド起動(Windows)。Python 3.10 以上のみ必要、pip install 不要。
cd /d %~dp0
if not exist .env copy .env.example .env >nul
python -m app.server
pause
