"""
開発者サポートAI - チェックリスト API サーバー(標準ライブラリのみ)。

起動:  cd backend && python -m app.server
       (既定 http://0.0.0.0:8000 。Angular を ng build した場合は同じポートで画面も配信)

API:
  GET  /api/health                      Ollama 接続確認・設定値
  GET  /api/branches?repo=PATH          ブランチ一覧
  POST /api/git/fetch                   {repo}  git fetch --prune origin
  POST /api/diff/files                  {repo, base, feature}  変更ファイル一覧(プレビュー)
  POST /api/checklists                  {repo, base, feature, issue, title, description, use_llm, fetch} → {job_id}
  GET  /api/jobs/{id}                   ジョブの進捗/結果
  GET  /api/checklists                  保存済みチェックリスト一覧
  GET  /api/checklists/{name}[?download=1]  保存済み Markdown
"""
from __future__ import annotations

import json
import mimetypes
import re
import sys
import traceback
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlparse

from . import git_diff as g
from .checklist import check_repo_allowed, generate_checklist, list_saved_checklists, read_saved_checklist
from .config import settings
from .jobs import jobs
from .ollama_client import OllamaClient, OllamaError


class ApiError(Exception):
    def __init__(self, status: int, message: str) -> None:
        super().__init__(message)
        self.status = status
        self.message = message


def _require(body: dict, *keys: str) -> list[str]:
    values = []
    for k in keys:
        v = str(body.get(k) or "").strip()
        if not v:
            raise ApiError(400, f"'{k}' を指定してください。")
        values.append(v)
    return values


def _repo(value: str) -> str:
    value = (value or settings.DEFAULT_REPO_PATH or "").strip()
    if not value:
        raise ApiError(400, "リポジトリのパスを指定してください。")
    return check_repo_allowed(value)


class Handler(BaseHTTPRequestHandler):
    server_version = "DevReviewAssistant/1.0"

    # ------------------------------------------------------------ 共通処理
    def log_message(self, fmt: str, *args) -> None:  # 標準エラーへ簡潔に
        sys.stderr.write(f"[{self.log_date_time_string()}] {self.command} {self.path} - {fmt % args}\n")

    def _cors(self) -> None:
        origin = self.headers.get("Origin")
        if origin and (origin in settings.CORS_ORIGINS or "*" in settings.CORS_ORIGINS):
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def _send_json(self, data, status: int = 200) -> None:
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self._cors()
        self.end_headers()
        self.wfile.write(body)

    def _send_text(self, text: str, content_type: str, download_name: str | None = None) -> None:
        body = text.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        if download_name:
            self.send_header("Content-Disposition", f"attachment; filename*=UTF-8''{quote(download_name)}")
        self._cors()
        self.end_headers()
        self.wfile.write(body)

    def _body(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if length > 1_000_000:
            raise ApiError(413, "リクエストが大きすぎます。")
        raw = self.rfile.read(length) if length else b"{}"
        try:
            data = json.loads(raw.decode("utf-8") or "{}")
        except json.JSONDecodeError:
            raise ApiError(400, "JSON の形式が正しくありません。")
        if not isinstance(data, dict):
            raise ApiError(400, "JSON オブジェクトを送信してください。")
        return data

    def _dispatch(self, handler) -> None:
        try:
            handler()
        except ApiError as e:
            self._send_json({"error": e.message}, e.status)
        except g.GitCommandError as e:
            self._send_json({"error": str(e)}, 400)
        except FileNotFoundError:
            self._send_json({"error": "見つかりません。"}, 404)
        except Exception as e:  # noqa: BLE001
            traceback.print_exc()
            self._send_json({"error": f"サーバーエラー: {e}"}, 500)

    def do_OPTIONS(self) -> None:  # CORS プリフライト
        self.send_response(HTTPStatus.NO_CONTENT)
        self._cors()
        self.end_headers()

    # ------------------------------------------------------------ ルーティング
    def do_GET(self) -> None:
        self._dispatch(self._route_get)

    def do_POST(self) -> None:
        self._dispatch(self._route_post)

    def _route_get(self) -> None:
        url = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(url.query).items()}
        path = url.path

        if path == "/api/health":
            info = {"model": settings.OLLAMA_CHAT_MODEL, "ollama_url": settings.OLLAMA_BASE_URL,
                    "default_repo": settings.DEFAULT_REPO_PATH, "default_base": settings.DEFAULT_BASE_BRANCH}
            try:
                info["ollama"] = OllamaClient(timeout=10).health()
            except OllamaError as e:
                info["ollama"] = {"reachable": False, "error": str(e)}
            return self._send_json(info)

        if path == "/api/branches":
            return self._send_json(g.list_branches(_repo(q.get("repo", ""))))

        m = re.fullmatch(r"/api/jobs/([0-9a-f]{12})", path)
        if m:
            job = jobs.get(m.group(1))
            if job is None:
                raise ApiError(404, "ジョブが見つかりません(サーバー再起動で消えた可能性があります)。")
            return self._send_json(job)

        if path == "/api/checklists":
            return self._send_json(list_saved_checklists())

        m = re.fullmatch(r"/api/checklists/([^/]+)", path)
        if m:
            name = m.group(1)
            text = read_saved_checklist(name)
            return self._send_text(text, "text/markdown; charset=utf-8",
                                   download_name=name if q.get("download") == "1" else None)

        if path.startswith("/api/"):
            raise ApiError(404, "API が見つかりません。")
        return self._serve_static(path)

    def _route_post(self) -> None:
        path = urlparse(self.path).path
        body = self._body()

        if path == "/api/git/fetch":
            fetched = g.fetch_remote(_repo(body.get("repo", "")), "origin")
            return self._send_json({"fetched": fetched})

        if path == "/api/diff/files":
            repo = _repo(body.get("repo", ""))
            base, feature = _require(body, "base", "feature")
            g.verify_branch_exists(repo, base)
            g.verify_branch_exists(repo, feature)
            return self._send_json({
                "files": g.get_changed_files(repo, base, feature),
                "commits": [c.__dict__ for c in g.get_commits(repo, base, feature)],
            })

        if path == "/api/checklists":
            repo = _repo(body.get("repo", ""))
            base, feature = _require(body, "base", "feature")
            g.validate_ref_name(base)
            g.validate_ref_name(feature)
            if base == feature:
                raise ApiError(400, "マージ先ブランチと feature ブランチが同じです。")
            g.verify_repo(repo)
            if not body.get("fetch"):
                g.verify_branch_exists(repo, base)
                g.verify_branch_exists(repo, feature)
            opts = dict(
                issue=str(body.get("issue") or "").strip().lstrip("#"),
                title=str(body.get("title") or "").strip(),
                description=str(body.get("description") or "").strip()[:2000],
                use_llm=bool(body.get("use_llm", True)),
                fetch=bool(body.get("fetch", False)),
            )
            job_id = jobs.submit(lambda progress: generate_checklist(
                repo, base, feature, progress=progress, **opts).to_dict())
            return self._send_json({"job_id": job_id}, 202)

        raise ApiError(404, "API が見つかりません。")

    # ------------------------------------------------------------ 画面配信(ng build 済みの場合)
    def _serve_static(self, path: str) -> None:
        root = Path(settings.STATIC_DIR)
        if not root.is_dir():
            return self._send_text(
                "開発者サポートAI API サーバーは起動しています。画面は Angular (frontend) を ng serve するか、"
                "ng build して STATIC_DIR に配置してください。", "text/plain; charset=utf-8")
        target = (root / path.lstrip("/")).resolve()
        if not str(target).startswith(str(root.resolve())) or not target.is_file():
            target = root / "index.html"  # SPA のルーティング
        data = target.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", mimetypes.guess_type(target.name)[0] or "application/octet-stream")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


def main() -> None:
    server = ThreadingHTTPServer((settings.HOST, settings.PORT), Handler)
    print(f"開発者サポートAI API: http://{settings.HOST}:{settings.PORT}  "
          f"(Ollama: {settings.OLLAMA_BASE_URL}, model: {settings.OLLAMA_CHAT_MODEL})")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
