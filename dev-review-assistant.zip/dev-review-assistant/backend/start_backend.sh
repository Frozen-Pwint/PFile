#!/usr/bin/env sh
# 開発者サポートAI バックエンド起動。Python 3.10 以上のみ必要、pip install 不要。
cd "$(dirname "$0")"
[ -f .env ] || cp .env.example .env
exec python3 -m app.server
