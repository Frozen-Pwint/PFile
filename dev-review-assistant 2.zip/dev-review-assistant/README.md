# 開発者サポートAI ― PR チェックリスト作成機能

プルリクエストの **マージ先ブランチ(origin 側。例: `origin/master`)** と **feature ブランチ** の差分を比較し、
レビュー・マージ前に確認すべき項目を **Markdown のチェックリスト** として作成します。

```
Issue 対応 → feature ブランチで実装 → push → PR 作成
                                              │
             origin/master ... feature/ISSUE-482 の差分(マージベース基準 = PR 画面と同じ差分)
                                              │
        ┌─────────────────────────────────────┴──────────────────────────────┐
        │ ① ルールベース(C# / Angular / HTML / CSS / SQL / 設定ファイル)       │
        │ ② 社内 Ollama の GPT(gpt-oss など)でファイルごとの確認項目            │
        │ ③ 社内 Ollama で PR 全体の要約とテスト観点                            │
        └─────────────────────────────────────┬──────────────────────────────┘
                                              ▼
                      checklist_issue482_<branch>_<日時>.md
```

## 構成

| 部分 | 技術 | 場所 |
|---|---|---|
| 画面 | Angular 18(standalone / signals) | `frontend/` |
| API | **FastAPI**(`app/main.py`、Swagger: `/docs`) | `backend/` |
| API(予備) | 標準ライブラリ版(`app/server.py`)。pip install できない環境用、同じ API | `backend/` |
| チェック処理 | Python 3.10+ 標準ライブラリ(git / Ollama 呼び出し) | `backend/app/` |
| AI | 社内 Ollama(`/api/chat`、既定モデル `gpt-oss:20b`) | `.env` で設定 |
| Git | git コマンド(subprocess) | レビュー対象リポジトリを指定 |

通常は FastAPI 版を使います。社内の証明書制限で pip が使えない場合でも、同じ API を
標準ライブラリだけで提供する `python -m app.server` に切り替えられます(処理本体 `app/services.py` は共通)。

```
backend/app/
  main.py        FastAPI アプリ(ルーティング・例外ハンドラ・CORS・画面配信)
  schemas.py     リクエスト/レスポンスの Pydantic モデル(/docs に表示)
  services.py    API の処理本体(FastAPI 版・標準ライブラリ版で共通)
  server.py      標準ライブラリ版サーバー(予備)
  checklist.py   差分 → ルール → AI → Markdown の生成
  rules.py       ルールベースのチェック定義
  llm_checklist.py / ollama_client.py   社内 Ollama 呼び出し
  git_diff.py    git 差分取得
  jobs.py        バックグラウンドジョブ(進捗)
```

## 起動手順

### 1. バックエンド

```bat
cd backend
copy .env.example .env      :: OLLAMA_BASE_URL / OLLAMA_CHAT_MODEL / DEFAULT_REPO_PATH を編集
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

`start_backend.bat` は FastAPI が入っていれば FastAPI 版、なければ標準ライブラリ版で起動します。

- `http://localhost:8000/docs` … Swagger UI(API を画面から試せます)
- `http://localhost:8000/api/health` … 社内 Ollama との接続状態とモデルの有無

pip が証明書エラーになる場合は `pip config set global.cert <社内CA証明書のパス>` を設定するか、社内 PyPI ミラーを使ってください。

社内 Ollama が https(社内 CA 署名)の場合は、`.env` の `OLLAMA_CA_BUNDLE` に社内 CA 証明書(.pem/.crt)のパスを指定してください。

### 2. 画面(Angular)

```bat
cd frontend
npm install                 :: 社内ミラー/証明書の設定が必要な場合は .npmrc.example を参照
npm start                   :: http://localhost:4200 (/api は localhost:8000 へプロキシ)
```

本番配置する場合は `npm run build` を実行すると `frontend/dist/checklist-ui/browser` に出力され、
バックエンドが同じポート(8000)で画面も配信します(`STATIC_DIR` で変更可)。

### 3. 使い方

1. リポジトリのパスを入力し「ブランチ取得」
2. マージ先に `origin/master`(または `origin/develop` など PR のマージ先)、feature に `origin/feature/ISSUE-xxx` を選択
3. Issue 番号・PR タイトル(・Issue の内容)を入力して「チェックリストを作成」
4. 画面上でチェックしながらレビューし、「Markdown をダウンロード」/「コピー」
   - 画面でチェックした項目は `- [x]` として Markdown に反映されます
   - PR の説明欄やコメントに貼り付けると、GitHub / GitLab / Azure DevOps でチェックボックスとして使えます

作成したファイルは `backend/output/checklists/` にも保存され、画面左下の「保存済み」から開けます。

## チェックリストの内容

| セクション | 内容 |
|---|---|
| 共通チェック | 要件充足・ビルド/テスト・コンフリクト・PR 説明。変更の種類に応じて出し分け(C# があれば dotnet build、DB 変更があれば検証環境での実行 など) |
| ファイル別チェック | ルール + AI。該当行番号(feature 側)付き。重要度 高/中/低 |
| テスト観点 | AI が変更内容から作る動作確認の観点(境界値・権限・デグレなど) |
| 変更ファイル一覧・コミット | PR に含まれるファイルとコミット |

ルールの例(`backend/app/rules.py` の `RULES` に追加するだけで拡張できます):

- **C#**: SQL の文字列連結、空 catch、`async void`、`.Result/.Wait()`、金額への `double`、`Math.Round` の丸め方式、トランザクション、`[AllowAnonymous]`、public メソッドのシグネチャ変更
- **Angular/TS**: subscribe の購読解除、HTTP のエラー処理、`any`、`console.log`、`bypassSecurityTrust`、新規コンポーネントの spec 有無、ルーティングのガード
- **HTML**: `[innerHTML]`、`*ngFor` の trackBy、入力項目のバリデーション、button の type(二重登録)
- **CSS**: `::ng-deep`、`!important`、色の直書き
- **SQL / 設定**: DROP/TRUNCATE、WHERE のない UPDATE/DELETE、appsettings / environment の環境別反映、package.json / csproj の依存関係

## 社内 Ollama を使わない/使えないとき

- 画面の「社内AIで…」のチェックを外すと、ルールベースのみで数秒で作成します。
- Ollama に接続できない場合は自動的にルールベースのみで作成し、その旨を Markdown の冒頭に記載します。
- 動作確認用に固定応答を返すモックがあります: `python backend/scripts/mock_ollama.py`

## API

| メソッド | パス | 内容 |
|---|---|---|
| GET | `/api/health` | 社内 Ollama の接続確認・設定 |
| GET | `/api/branches?repo=...` | ブランチ一覧(ローカル/リモート) |
| POST | `/api/git/fetch` | `{repo}` git fetch --prune origin |
| POST | `/api/diff/files` | `{repo, base, feature}` 変更ファイルとコミット |
| POST | `/api/checklists` | `{repo, base, feature, issue, title, description, use_llm, fetch}` → `{job_id}` |
| GET | `/api/jobs/{id}` | 進捗と結果(`result.markdown` に Markdown) |
| GET | `/api/checklists` | 保存済み一覧 |
| GET | `/api/checklists/{name}?download=1` | 保存済み Markdown |

## テスト

```bat
cd backend
python -m unittest discover -s tests -v
```

FastAPI と httpx がインストールされていれば、FastAPI の TestClient による API テストも実行されます(未インストールなら自動でスキップ)。

## 主な設定(.env)

| 変数 | 既定値 | 説明 |
|---|---|---|
| `OLLAMA_BASE_URL` | `http://localhost:11434` | 社内 Ollama の URL |
| `OLLAMA_CHAT_MODEL` | `gpt-oss:20b` | 使用するモデル(`/api/health` の models で確認) |
| `OLLAMA_CA_BUNDLE` | (空) | 社内 CA 証明書のパス |
| `LLM_MAX_CHARS_PER_CALL` | `12000` | 1 回に送る差分の最大文字数。大きい差分はハンク単位で分割 |
| `LLM_CONCURRENCY` | `2` | Ollama への同時リクエスト数 |
| `DEFAULT_REPO_PATH` | (空) | 画面のリポジトリ初期値 |
| `DEFAULT_BASE_BRANCH` | `origin/master` | マージ先の初期値 |
| `ALLOWED_REPO_ROOTS` | (空) | 指定できるリポジトリを制限(; 区切り) |
| `EXCLUDE_PATTERNS` | ロックファイル・画像・bin/obj 等 | チェック対象外(glob, ; 区切り) |

> ソースコードの差分は社内 Ollama にのみ送信されます。外部サービスには送信しません。
