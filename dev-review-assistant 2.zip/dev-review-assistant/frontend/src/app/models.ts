export type Severity = 'high' | 'medium' | 'low';

export interface ChecklistItem {
  check: string;
  category: string;
  severity: Severity;
  reason: string;
  file: string | null;
  lines: number[];
  source: 'rule' | 'ai' | 'common';
  rule_id: string;
  idx: number;
}

export interface ChangedFile {
  path: string;
  old_path: string | null;
  status: 'added' | 'modified' | 'deleted' | 'renamed' | 'copied';
  language: string;
  additions: number;
  deletions: number;
  excluded: boolean;
  item_count: number;
}

export interface Commit {
  sha: string;
  author: string;
  date: string;
  subject: string;
}

export interface ChecklistMeta {
  repo: string;
  base: string;
  feature: string;
  base_sha: string;
  feature_sha: string;
  merge_base: string;
  issue: string;
  title: string;
  generated_at: string;
  model: string | null;
  file_count: number;
  additions: number;
  deletions: number;
  commit_count: number;
}

export interface ChecklistResult {
  meta: ChecklistMeta;
  summary: string;
  common_items: ChecklistItem[];
  file_items: Record<string, ChecklistItem[]>;
  test_items: ChecklistItem[];
  files: ChangedFile[];
  commits: Commit[];
  warnings: string[];
  markdown: string;
  file_name: string;
}

export interface Job {
  id: string;
  status: 'running' | 'done' | 'error';
  phase: string;
  current: number;
  total: number;
  message: string;
  elapsed_sec: number;
  result: ChecklistResult | null;
  error: string | null;
}

export interface BranchRef {
  name: string;
  date: string;
  subject: string;
}

export interface BranchList {
  current: string;
  local: BranchRef[];
  remote: BranchRef[];
}

export interface Health {
  model: string;
  ollama_url: string;
  default_repo: string;
  default_base: string;
  ollama: { reachable: boolean; model_available?: boolean; models?: string[]; error?: string };
}

export interface SavedChecklist {
  name: string;
  size: number;
  modified: string;
}

export interface ChecklistRequest {
  repo: string;
  base: string;
  feature: string;
  issue: string;
  title: string;
  description: string;
  use_llm: boolean;
  fetch: boolean;
}
