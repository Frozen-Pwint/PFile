import { Component, computed, effect, input, signal, untracked } from '@angular/core';
import { ChangedFile, ChecklistItem, ChecklistResult, Severity } from '../models';

interface Section {
  key: string;
  title: string;
  file?: ChangedFile;
  items: ChecklistItem[];
}

type SeverityFilter = 'all' | Severity;

const SEVERITY_LABEL: Record<Severity, string> = { high: '高', medium: '中', low: '低' };
const STATUS_LABEL: Record<string, string> = {
  added: '追加', modified: '変更', deleted: '削除', renamed: '名前変更', copied: 'コピー',
};
const LANG_LABEL: Record<string, string> = {
  csharp: 'C#', typescript: 'TypeScript', 'typescript-test': 'テスト', html: 'HTML', css: 'CSS',
  sql: 'SQL', json: 'JSON', config: '設定', msbuild: 'csproj', other: 'その他',
};

@Component({
  selector: 'app-checklist-view',
  standalone: true,
  templateUrl: './checklist-view.component.html',
  styleUrl: './checklist-view.component.css',
})
export class ChecklistViewComponent {
  /** 今回作成した結果(構造化データあり) */
  readonly result = input<ChecklistResult | null>(null);
  /** 保存済み Markdown を開いた場合 */
  readonly savedName = input<string>('');
  readonly savedMarkdown = input<string>('');

  readonly tab = signal<'list' | 'markdown'>('list');
  readonly severity = signal<SeverityFilter>('all');
  readonly aiOnly = signal(false);
  readonly hideDone = signal(false);
  readonly checked = signal<ReadonlySet<number>>(new Set());
  readonly copied = signal(false);

  readonly severityLabel = SEVERITY_LABEL;
  readonly statusLabel: Record<string, string | undefined> = STATUS_LABEL;
  readonly langLabel: Record<string, string | undefined> = LANG_LABEL;

  readonly allItems = computed<ChecklistItem[]>(() => {
    const r = this.result();
    if (!r) return [];
    return [...r.common_items, ...Object.values(r.file_items).flat(), ...r.test_items];
  });

  readonly counts = computed(() => {
    const items = this.allItems();
    return {
      all: items.length,
      high: items.filter((i) => i.severity === 'high').length,
      medium: items.filter((i) => i.severity === 'medium').length,
      low: items.filter((i) => i.severity === 'low').length,
      ai: items.filter((i) => i.source === 'ai').length,
    };
  });

  readonly doneCount = computed(() => this.allItems().filter((i) => this.checked().has(i.idx)).length);
  readonly donePercent = computed(() => {
    const total = this.allItems().length;
    return total ? Math.round((this.doneCount() / total) * 100) : 0;
  });

  readonly sections = computed<Section[]>(() => {
    const r = this.result();
    if (!r) return [];
    const sev = this.severity();
    const aiOnly = this.aiOnly();
    const hideDone = this.hideDone();
    const done = this.checked();
    const keep = (i: ChecklistItem) =>
      (sev === 'all' || i.severity === sev) && (!aiOnly || i.source === 'ai') && (!hideDone || !done.has(i.idx));

    const out: Section[] = [{ key: 'common', title: '共通チェック', items: r.common_items.filter(keep) }];
    for (const f of r.files) {
      const items = (r.file_items[f.path] ?? []).filter(keep);
      if (items.length) out.push({ key: f.path, title: f.path, file: f, items });
    }
    if (r.test_items.length) out.push({ key: 'tests', title: 'テスト観点', items: r.test_items.filter(keep) });
    return out.filter((s) => s.items.length > 0);
  });

  /** 画面でのチェック状態を反映した Markdown(- [ ] → - [x]) */
  readonly markdown = computed(() => {
    const r = this.result();
    if (!r) return this.savedMarkdown();
    const done = this.checked();
    let n = -1;
    return r.markdown
      .split('\n')
      .map((line) => {
        if (!line.startsWith('- [ ] ')) return line;
        n += 1;
        return done.has(n) ? '- [x] ' + line.slice(6) : line;
      })
      .join('\n');
  });

  readonly fileName = computed(() => this.result()?.file_name || this.savedName() || 'checklist.md');

  constructor() {
    // 結果が切り替わったら、そのチェックリストのチェック状態を復元する
    effect(() => {
      const name = this.result()?.file_name;
      untracked(() => {
        this.checked.set(new Set(name ? this.loadChecks(name) : []));
        this.tab.set(this.result() ? 'list' : 'markdown');
        this.severity.set('all');
        this.aiOnly.set(false);
        this.hideDone.set(false);
      });
    }, { allowSignalWrites: true });
  }

  toggle(item: ChecklistItem): void {
    const next = new Set(this.checked());
    if (next.has(item.idx)) next.delete(item.idx);
    else next.add(item.idx);
    this.checked.set(next);
    const name = this.result()?.file_name;
    if (name) this.saveChecks(name, [...next]);
  }

  isChecked(item: ChecklistItem): boolean {
    return this.checked().has(item.idx);
  }

  lineLabel(item: ChecklistItem): string {
    if (!item.lines.length) return '';
    const shown = item.lines.slice(0, 4).map((l) => `L${l}`).join(', ');
    return item.lines.length > 4 ? `${shown} ほか` : shown;
  }

  download(): void {
    const blob = new Blob([this.markdown()], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = this.fileName();
    a.click();
    URL.revokeObjectURL(url);
  }

  async copy(): Promise<void> {
    try {
      await navigator.clipboard.writeText(this.markdown());
      this.copied.set(true);
      setTimeout(() => this.copied.set(false), 2000);
    } catch {
      this.tab.set('markdown'); // クリップボードが使えない場合は手動コピー用に表示
    }
  }

  private loadChecks(name: string): number[] {
    try {
      const raw = localStorage.getItem(`pr-checklist.checks.${name}`);
      return raw ? (JSON.parse(raw) as number[]) : [];
    } catch {
      return [];
    }
  }

  private saveChecks(name: string, values: number[]): void {
    try {
      localStorage.setItem(`pr-checklist.checks.${name}`, JSON.stringify(values));
    } catch {
      /* 保存できなくても画面上のチェックは有効 */
    }
  }
}
