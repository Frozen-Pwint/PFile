import { Component, DestroyRef, OnInit, computed, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { Subscription, timer } from 'rxjs';
import { switchMap, takeWhile } from 'rxjs/operators';
import { ApiService } from './api.service';
import { ChecklistViewComponent } from './checklist-view/checklist-view.component';
import { BranchList, ChecklistRequest, ChecklistResult, Health, Job, SavedChecklist } from './models';

const FORM_STORAGE_KEY = 'pr-checklist.form';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FormsModule, ChecklistViewComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent implements OnInit {
  private readonly api = inject(ApiService);
  private readonly destroyRef = inject(DestroyRef);
  private pollSub?: Subscription;

  // 入力フォーム
  form: ChecklistRequest = {
    repo: '',
    base: 'origin/master',
    feature: '',
    issue: '',
    title: '',
    description: '',
    use_llm: true,
    fetch: true,
  };

  readonly health = signal<Health | null>(null);
  readonly branches = signal<BranchList | null>(null);
  readonly branchError = signal<string>('');
  readonly loadingBranches = signal(false);

  readonly job = signal<Job | null>(null);
  readonly error = signal<string>('');
  readonly result = signal<ChecklistResult | null>(null);

  readonly saved = signal<SavedChecklist[]>([]);
  readonly savedView = signal<{ name: string; markdown: string } | null>(null);

  readonly running = computed(() => this.job()?.status === 'running');
  readonly aiReady = computed(() => this.health()?.ollama.reachable === true);
  readonly remoteBranches = computed(() => this.branches()?.remote ?? []);
  readonly allBranches = computed(() => {
    const b = this.branches();
    return b ? [...b.remote, ...b.local] : [];
  });
  readonly progressPercent = computed(() => {
    const j = this.job();
    if (!j) return 0;
    const steps: Record<string, number> = { queued: 2, fetch: 5, diff: 10, rules: 15, summary: 92, render: 97, done: 100 };
    if (j.phase === 'ai') return j.total > 0 ? 15 + Math.round((j.current / j.total) * 75) : 15;
    return steps[j.phase] ?? 5;
  });

  ngOnInit(): void {
    this.restoreForm();
    this.api
      .health()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (h) => {
          this.health.set(h);
          if (!this.form.repo && h.default_repo) this.form.repo = h.default_repo;
          if (!this.form.base && h.default_base) this.form.base = h.default_base;
          if (!h.ollama.reachable) this.form.use_llm = false;
          if (this.form.repo) this.loadBranches();
        },
        error: (e: Error) => this.error.set(e.message),
      });
    this.refreshSaved();
  }

  loadBranches(): void {
    if (!this.form.repo.trim()) {
      this.branchError.set('リポジトリのパスを入力してください。');
      return;
    }
    this.loadingBranches.set(true);
    this.branchError.set('');
    this.api
      .branches(this.form.repo.trim())
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (b) => {
          this.branches.set(b);
          this.loadingBranches.set(false);
          if (!this.form.feature && b.current && b.current !== 'HEAD' && !/^(master|main|develop)$/.test(b.current)) {
            this.form.feature = b.current;
          }
        },
        error: (e: Error) => {
          this.branches.set(null);
          this.branchError.set(e.message);
          this.loadingBranches.set(false);
        },
      });
  }

  /** origin のブランチ名なら Issue 番号を推測して入力補助する(例: feature/ISSUE-482-xxx → 482) */
  onFeatureChange(): void {
    if (this.form.issue) return;
    const m = this.form.feature.match(/(?:issue|#|^|\/)[-_]?(\d{2,6})(?:\D|$)/i);
    if (m) this.form.issue = m[1];
  }

  submit(): void {
    this.error.set('');
    if (!this.form.repo.trim() || !this.form.base.trim() || !this.form.feature.trim()) {
      this.error.set('リポジトリ、マージ先ブランチ、feature ブランチを入力してください。');
      return;
    }
    if (this.form.base.trim() === this.form.feature.trim()) {
      this.error.set('マージ先ブランチと feature ブランチが同じです。');
      return;
    }
    this.saveForm();
    this.result.set(null);
    this.savedView.set(null);
    this.job.set({
      id: '', status: 'running', phase: 'queued', current: 0, total: 0,
      message: '開始しています', elapsed_sec: 0, result: null, error: null,
    });

    const req: ChecklistRequest = { ...this.form, repo: this.form.repo.trim(), base: this.form.base.trim(), feature: this.form.feature.trim() };
    this.api
      .createChecklist(req)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: ({ job_id }) => this.poll(job_id),
        error: (e: Error) => {
          this.job.set(null);
          this.error.set(e.message);
        },
      });
  }

  private poll(jobId: string): void {
    this.pollSub?.unsubscribe();
    this.pollSub = timer(0, 1500)
      .pipe(
        switchMap(() => this.api.job(jobId)),
        takeWhile((j) => j.status === 'running', true),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe({
        next: (j) => {
          this.job.set(j);
          if (j.status === 'done' && j.result) {
            this.result.set(j.result);
            this.refreshSaved();
          } else if (j.status === 'error') {
            this.error.set(j.error ?? 'チェックリストの作成に失敗しました。');
          }
        },
        error: (e: Error) => {
          this.job.set(null);
          this.error.set(e.message);
        },
      });
  }

  refreshSaved(): void {
    this.api
      .savedList()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({ next: (list) => this.saved.set(list), error: () => this.saved.set([]) });
  }

  openSaved(item: SavedChecklist): void {
    this.api
      .savedMarkdown(item.name)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (md) => {
          this.result.set(null);
          this.job.set(null);
          this.savedView.set({ name: item.name, markdown: md });
        },
        error: (e: Error) => this.error.set(e.message),
      });
  }

  private saveForm(): void {
    try {
      const { repo, base, use_llm, fetch } = this.form;
      localStorage.setItem(FORM_STORAGE_KEY, JSON.stringify({ repo, base, use_llm, fetch }));
    } catch {
      /* ストレージが使えない環境では保存しない */
    }
  }

  private restoreForm(): void {
    try {
      const raw = localStorage.getItem(FORM_STORAGE_KEY);
      if (raw) Object.assign(this.form, JSON.parse(raw));
    } catch {
      /* 無視 */
    }
  }
}
