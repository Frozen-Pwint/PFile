#!/usr/bin/env sh
# 開発者サポートAI バックエンド起動。FastAPI があれば uvicorn、なければ標準ライブラリ版。
cd "$(dirname "$0")"
[ -f .env ] || cp .env.example .env
if python3 -c "import fastapi, uvicorn" 2>/dev/null; then
  echo "FastAPI 版で起動します  http://localhost:8000/docs"
  exec python3 -m app.main
else
  echo "FastAPI が見つからないため標準ライブラリ版で起動します (pip install -r requirements.txt で FastAPI 版になります)"
  exec python3 -m app.server
fi
