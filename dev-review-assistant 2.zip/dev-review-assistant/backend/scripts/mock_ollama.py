"""
動作確認用の Ollama モックサーバー(社内 Ollama に接続できない環境での画面・API 確認用)。

起動:  python scripts/mock_ollama.py  (http://localhost:11434)
       .env の OLLAMA_BASE_URL=http://localhost:11434 のまま backend を起動すると、
       このモックの固定応答でチェックリストが作成される。
"""
from __future__ import annotations

import json
import re
import sys
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

MODEL = "gpt-oss:20b"


def _file_answer(user: str) -> dict:
    path = re.search(r"ファイル: (\S+)", user)
    path = path.group(1) if path else "?"
    line = re.search(r"\[L(\d+)\] \+", user)
    ln = int(line.group(1)) if line else None
    return {
        "summary": f"{path} の変更(モック応答)。",
        "items": [{
            "check": f"{path.split('/')[-1]} の変更が既存の呼び出し元・画面に影響しないか",
            "category": "影響範囲", "severity": "medium",
            "reason": "モック応答: 実際の社内 Ollama では差分に応じた項目が生成されます。", "line": ln,
        }],
    }


def _summary_answer() -> dict:
    return {
        "summary": "モック応答: 受注取消に理由入力と値引率を追加する変更です。",
        "tests": [
            {"check": "値引率 0% / 100% / 小数の境界値で合計金額が正しいことを確認する", "severity": "high",
             "reason": "金額計算の変更があるため。"},
            {"check": "権限のないユーザーで取消 API を呼び出し、拒否されることを確認する", "severity": "high",
             "reason": "更新系 API が追加されたため。"},
        ],
    }


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        sys.stderr.write("[mock-ollama] " + fmt % args + "\n")

    def _json(self, data, status=200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/api/tags":
            return self._json({"models": [{"name": MODEL}]})
        self._json({"error": "not found"}, 404)

    def do_POST(self):
        req = json.loads(self.rfile.read(int(self.headers.get("Content-Length") or 0)) or b"{}")
        if self.path != "/api/chat":
            return self._json({"error": "not found"}, 404)
        system = req["messages"][0]["content"]
        user = req["messages"][-1]["content"]
        time.sleep(0.2)
        answer = _summary_answer() if "テックリード" in system else _file_answer(user)
        self._json({"model": req.get("model"), "message": {"role": "assistant",
                    "content": json.dumps(answer, ensure_ascii=False)}, "done": True})


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 11434
    print(f"mock ollama on http://localhost:{port}")
    ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()
