@echo off
rem 開発者サポートAI バックエンド起動(Windows)
rem   FastAPI が入っていれば uvicorn で起動、なければ標準ライブラリ版で起動します。
cd /d %~dp0
if not exist .env copy .env.example .env >nul
python -c "import fastapi, uvicorn" 2>nul
if %errorlevel%==0 (
  echo FastAPI 版で起動します  http://localhost:8000/docs
  python -m app.main
) else (
  echo FastAPI が見つからないため標準ライブラリ版で起動します  ^(pip install -r requirements.txt で FastAPI 版になります^)
  python -m app.server
)
pause
