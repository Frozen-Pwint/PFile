"""
チェックリスト生成のテスト(標準ライブラリ unittest のみ)。

実行:  cd backend && python -m unittest discover -s tests -v
"""
from __future__ import annotations

import os
import subprocess
import tempfile
import unittest
from pathlib import Path

_TMP_OUT = tempfile.mkdtemp()
os.environ["CHECKLIST_OUTPUT_DIR"] = _TMP_OUT

from app import git_diff as g  # noqa: E402
from app.checklist import generate_checklist, read_saved_checklist  # noqa: E402
from app.llm_checklist import format_diff_for_llm, split_hunks  # noqa: E402
from app.ollama_client import OllamaError, extract_json  # noqa: E402
from app.rules import analyze_file, is_excluded  # noqa: E402


def git(cwd, *args):
    subprocess.run(["git", *args], cwd=cwd, check=True, capture_output=True)


def make_repo() -> str:
    """origin(bare) + master + feature ブランチを持つテスト用リポジトリを作る。"""
    root = Path(tempfile.mkdtemp())
    git(root, "init", "-q", "--bare", "-b", "master", "origin.git")
    work = root / "work"
    git(root, "clone", "-q", "origin.git", "work")
    git(work, "config", "user.email", "t@example.com")
    git(work, "config", "user.name", "tester")
    git(work, "checkout", "-q", "-B", "master")
    (work / "Svc.cs").write_text("public class Svc {\n    public decimal Total(decimal p) { return p; }\n}\n", encoding="utf-8")
    git(work, "add", "-A"); git(work, "commit", "-qm", "init"); git(work, "push", "-q", "origin", "master")
    git(work, "checkout", "-qb", "feature/x")
    (work / "Svc.cs").write_text(
        "public class Svc {\n    public decimal Total(decimal p, double rate) {\n"
        "        var sql = \"SELECT * FROM T WHERE id = \" + p;\n"
        "        try { Run(sql); } catch (Exception) { }\n        return p;\n    }\n}\n", encoding="utf-8")
    (work / "a.component.ts").write_text("export class A { x: any; init() { this.http.get('/x').subscribe(); } }\n", encoding="utf-8")
    (work / "package-lock.json").write_text("{}\n", encoding="utf-8")
    git(work, "add", "-A"); git(work, "commit", "-qm", "#1 feature"); git(work, "push", "-q", "origin", "feature/x")
    git(work, "checkout", "-q", "master")
    return str(work)


class FakeClient:
    """OllamaClient の代わり。呼ばれたプロンプトを記録して固定 JSON を返す。"""
    base_url = "http://fake"
    model = "gpt-oss:20b"

    def __init__(self, fail=False):
        self.fail = fail
        self.calls = []

    def chat_json(self, system, user):
        self.calls.append((system, user))
        if self.fail:
            raise OllamaError("down")
        if "テックリード" in system:
            return {"summary": "全体要約", "tests": [{"check": "境界値を確認する", "severity": "高"}]}
        return {"summary": "要約", "items": [{"check": "AI項目", "category": "業務ロジック", "severity": "high", "line": 2}]}


class DiffParseTest(unittest.TestCase):
    def test_parse_line_numbers(self):
        diff = "diff --git a/x b/x\n--- a/x\n+++ b/x\n@@ -1,3 +1,4 @@\n a\n-b\n+B\n+C\n c\n"
        hunks = g.parse_unified_diff(diff)
        self.assertEqual(len(hunks), 1)
        adds = [(l.content, l.new_lineno) for l in hunks[0].lines if l.kind == "add"]
        self.assertEqual(adds, [("B", 2), ("C", 3)])
        dels = [(l.content, l.old_lineno) for l in hunks[0].lines if l.kind == "del"]
        self.assertEqual(dels, [("b", 2)])

    def test_ref_validation(self):
        with self.assertRaises(g.GitCommandError):
            g.validate_ref_name("--upload-pack=evil")
        with self.assertRaises(g.GitCommandError):
            g.validate_ref_name("a..b")
        self.assertEqual(g.validate_ref_name("origin/feature/ISSUE-1_x"), "origin/feature/ISSUE-1_x")


class RulesTest(unittest.TestCase):
    def _fd(self, path, added):
        h = g.DiffHunk("@@ -0,0 +1 @@", 0, 0, 1, len(added),
                       [g.DiffLine("add", t, None, i + 1) for i, t in enumerate(added)])
        return g.FileDiff(path, None, "added", g.detect_language(path), hunks=[h])

    def test_csharp_rules(self):
        fd = self._fd("Svc.cs", ['var s = "SELECT a FROM t WHERE x = " + id;', "catch (Exception) { }", "public async void Go() {}"])
        ids = {i.rule_id for i in analyze_file(fd, {fd.path})}
        self.assertTrue({"CS-SQL-CONCAT", "CS-EMPTY-CATCH", "CS-ASYNC-VOID"} <= ids)

    def test_html_exclude(self):
        fd = self._fd("a.component.html", ['<tr *ngFor="let o of list; trackBy: byId">', '<img src="a.png" alt="a">'])
        ids = {i.rule_id for i in analyze_file(fd, {fd.path})}
        self.assertNotIn("HTML-NGFOR-TRACK", ids)
        self.assertNotIn("HTML-IMG-ALT", ids)

    def test_new_component_without_spec(self):
        fd = self._fd("src/app/b.component.ts", ["export class B {}"])
        ids = {i.rule_id for i in analyze_file(fd, {fd.path})}
        self.assertIn("NG-NO-SPEC", ids)
        ids2 = {i.rule_id for i in analyze_file(fd, {fd.path, "src/app/b.component.spec.ts"})}
        self.assertNotIn("NG-NO-SPEC", ids2)

    def test_exclude_patterns(self):
        self.assertTrue(is_excluded("web/package-lock.json", ["package-lock.json"]))
        self.assertTrue(is_excluded("bin/Debug/a.dll", ["*.dll"]))
        self.assertFalse(is_excluded("src/a.cs", ["*.dll"]))


class LlmHelpersTest(unittest.TestCase):
    def test_extract_json_with_fence(self):
        self.assertEqual(extract_json('説明\n```json\n{"a": 1}\n```'), {"a": 1})

    def test_split_hunks(self):
        lines = [g.DiffLine("add", "x" * 100, None, i) for i in range(1, 5)]
        fd = g.FileDiff("a.cs", None, "modified", "csharp",
                        hunks=[g.DiffHunk(f"@@ -{i} +{i} @@", i, 1, i, 1, list(lines)) for i in range(5)])
        groups = split_hunks(fd, 900)
        self.assertGreater(len(groups), 1)
        self.assertEqual(sum(len(x) for x in groups), 5)
        self.assertIn("[L1] + ", format_diff_for_llm(fd, groups[0]))


class EndToEndTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.repo = make_repo()

    def test_generate_with_ai(self):
        import app.checklist as ck
        original = ck.OllamaClient
        ck.OllamaClient = lambda **kw: type("H", (), {"health": lambda self: {}})()  # 接続確認をスキップ
        try:
            client = FakeClient()
            r = generate_checklist(self.repo, "origin/master", "origin/feature/x", issue="1", title="t",
                                   use_llm=True, fetch=True, client=client)
        finally:
            ck.OllamaClient = original
        self.assertEqual(r.meta["commit_count"], 1)
        paths = [f["path"] for f in r.files]
        self.assertIn("package-lock.json", paths)
        self.assertNotIn("package-lock.json", r.file_items)      # 除外対象
        svc = {i.rule_id for i in r.file_items["Svc.cs"]}
        self.assertIn("CS-SQL-CONCAT", svc)
        self.assertIn("CS-PUBLIC-API", svc)
        self.assertTrue(any(i.source == "ai" for i in r.file_items["Svc.cs"]))
        self.assertEqual(r.summary, "全体要約")
        self.assertEqual(r.test_items[0].severity, "high")
        md = read_saved_checklist(r.file_name)
        self.assertIn("# PR チェックリスト: #1 t", md)
        self.assertIn("- [ ] 🔴 **[高]**", md)
        self.assertIn("## 3. テスト観点", md)

    def test_generate_rules_only(self):
        r = generate_checklist(self.repo, "origin/master", "origin/feature/x", use_llm=False)
        self.assertIsNone(r.meta["model"])
        self.assertFalse(any(i.source == "ai" for v in r.file_items.values() for i in v))
        self.assertIn("ルールベースのみ", r.markdown)

    def test_ai_all_failed_falls_back(self):
        import app.checklist as ck
        original = ck.OllamaClient
        ck.OllamaClient = lambda **kw: type("H", (), {"health": lambda self: {}})()
        try:
            r = generate_checklist(self.repo, "origin/master", "origin/feature/x", client=FakeClient(fail=True))
        finally:
            ck.OllamaClient = original
        self.assertIsNone(r.meta["model"])
        self.assertTrue(any("すべて失敗" in w for w in r.warnings))

    def test_bad_branch(self):
        with self.assertRaises(g.GitCommandError):
            generate_checklist(self.repo, "origin/master", "origin/none", use_llm=False)

    def test_path_traversal_blocked(self):
        with self.assertRaises(FileNotFoundError):
            read_saved_checklist("../app/config.py")


if __name__ == "__main__":
    unittest.main()
