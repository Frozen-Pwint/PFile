"""
API のテスト。

- SchemaTest: services の戻り値が Pydantic スキーマ(FastAPI の response_model)に合うか
- FastApiTest: FastAPI の TestClient で API を通しで確認(fastapi / httpx が入っている場合のみ実行)

実行:  cd backend && python -m unittest discover -s tests -v
"""
from __future__ import annotations

import importlib.util
import os
import tempfile
import time
import unittest

os.environ.setdefault("CHECKLIST_OUTPUT_DIR", tempfile.mkdtemp())
os.environ["OLLAMA_BASE_URL"] = "http://127.0.0.1:9"  # 接続できない URL(ルールベースのみで動かす)

from test_checklist import make_repo  # noqa: E402

from app import services  # noqa: E402
from app.checklist import generate_checklist  # noqa: E402

HAS_PYDANTIC = importlib.util.find_spec("pydantic") is not None
HAS_FASTAPI = all(importlib.util.find_spec(m) is not None for m in ("fastapi", "httpx"))


@unittest.skipUnless(HAS_PYDANTIC, "pydantic が未インストール")
class SchemaTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.repo = make_repo()

    def test_branches_and_diff(self):
        from app.schemas import BranchList, DiffFilesResponse
        b = BranchList.model_validate(services.branches(self.repo))
        self.assertIn("origin/feature/x", [r.name for r in b.remote])
        d = DiffFilesResponse.model_validate(services.diff_files(self.repo, "origin/master", "origin/feature/x"))
        self.assertEqual(len(d.commits), 1)

    def test_health_unreachable(self):
        from app.schemas import HealthResponse
        h = HealthResponse.model_validate(services.health())
        self.assertFalse(h.ollama.reachable)

    def test_job_result(self):
        from app.schemas import JobResponse
        r = generate_checklist(self.repo, "origin/master", "origin/feature/x", use_llm=False)
        job = {"id": "abc", "status": "done", "phase": "done", "current": 1, "total": 1, "message": "",
               "elapsed_sec": 0.1, "result": r.to_dict(), "error": None, "started_at": 0, "finished_at": 1}
        j = JobResponse.model_validate(job)
        self.assertGreater(len(j.result.common_items), 0)
        self.assertTrue(all(i.idx >= 0 for v in j.result.file_items.values() for i in v))

    def test_request_defaults(self):
        from app.schemas import ChecklistRequest
        req = ChecklistRequest(base="origin/master", feature="origin/feature/x")
        self.assertTrue(req.use_llm)
        self.assertFalse(req.fetch)


@unittest.skipUnless(HAS_FASTAPI, "fastapi / httpx が未インストール")
class FastApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from fastapi.testclient import TestClient
        from app.main import app
        cls.repo = make_repo()
        cls.client = TestClient(app)

    def test_health(self):
        res = self.client.get("/api/health")
        self.assertEqual(res.status_code, 200)
        self.assertFalse(res.json()["ollama"]["reachable"])

    def test_branches(self):
        res = self.client.get("/api/branches", params={"repo": self.repo})
        self.assertEqual(res.status_code, 200)
        self.assertIn("origin/master", [b["name"] for b in res.json()["remote"]])

    def test_create_and_poll(self):
        res = self.client.post("/api/checklists", json={
            "repo": self.repo, "base": "origin/master", "feature": "origin/feature/x",
            "issue": "#1", "title": "t", "use_llm": False})
        self.assertEqual(res.status_code, 202)
        job_id = res.json()["job_id"]
        for _ in range(50):
            job = self.client.get(f"/api/jobs/{job_id}").json()
            if job["status"] != "running":
                break
            time.sleep(0.1)
        self.assertEqual(job["status"], "done", job.get("error"))
        name = job["result"]["file_name"]
        md = self.client.get(f"/api/checklists/{name}", params={"download": "true"})
        self.assertEqual(md.status_code, 200)
        self.assertIn("attachment", md.headers["content-disposition"])
        self.assertIn("# PR チェックリスト: #1 t", md.text)
        self.assertIn(name, [s["name"] for s in self.client.get("/api/checklists").json()])

    def test_error_format(self):
        res = self.client.post("/api/checklists", json={"repo": self.repo, "base": "origin/master", "feature": "origin/none"})
        self.assertEqual(res.status_code, 400)
        self.assertIn("見つかりません", res.json()["error"])
        res = self.client.post("/api/checklists", json={"repo": self.repo, "base": "--evil", "feature": "x"})
        self.assertEqual(res.status_code, 400)
        res = self.client.post("/api/checklists", json={"repo": self.repo})
        self.assertEqual(res.status_code, 422)
        self.assertIn("error", res.json())
        self.assertEqual(self.client.get("/api/jobs/000000000000").status_code, 404)
        self.assertEqual(self.client.get("/api/checklists/..%2Fconfig.py").status_code, 404)
        self.assertEqual(self.client.get("/api/unknown").status_code, 404)


if __name__ == "__main__":
    unittest.main()
