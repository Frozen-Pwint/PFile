"""
社内 Ollama クライアント(標準ライブラリ urllib のみ使用)。

社内 Ollama で公開されている GPT 系モデル(例: gpt-oss:20b)を
Ollama ネイティブ API `/api/chat` で呼び出す。

証明書について:
  - 社内 CA で署名された https エンドポイントの場合は OLLAMA_CA_BUNDLE に
    社内 CA 証明書(.pem/.crt)のパスを指定する。
  - 検証を無効化する OLLAMA_VERIFY_TLS=false は最終手段(セキュリティ部門と相談の上で)。
"""
from __future__ import annotations

import json
import re
import ssl
import urllib.error
import urllib.request
from typing import Any, Optional

from .config import settings


class OllamaError(RuntimeError):
    """Ollama 呼び出し失敗。"""


class OllamaClient:
    def __init__(
        self,
        base_url: Optional[str] = None,
        model: Optional[str] = None,
        api_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> None:
        self.base_url = (base_url or settings.OLLAMA_BASE_URL).rstrip("/")
        self.model = model or settings.OLLAMA_CHAT_MODEL
        self.api_key = api_key if api_key is not None else settings.OLLAMA_API_KEY
        self.timeout = timeout or settings.OLLAMA_TIMEOUT_SEC
        self._ssl_context = self._build_ssl_context()

    @staticmethod
    def _build_ssl_context() -> Optional[ssl.SSLContext]:
        if settings.OLLAMA_CA_BUNDLE:
            return ssl.create_default_context(cafile=settings.OLLAMA_CA_BUNDLE)
        if not settings.OLLAMA_VERIFY_TLS:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            return ctx
        return None

    def _request(self, method: str, path: str, body: Optional[dict] = None) -> dict:
        url = f"{self.base_url}{path}"
        data = json.dumps(body).encode("utf-8") if body is not None else None
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            kwargs: dict[str, Any] = {"timeout": self.timeout}
            if url.startswith("https") and self._ssl_context is not None:
                kwargs["context"] = self._ssl_context
            with urllib.request.urlopen(req, **kwargs) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")[:500]
            raise OllamaError(f"Ollama が HTTP {exc.code} を返しました ({url}): {detail}") from exc
        except urllib.error.URLError as exc:
            reason = str(exc.reason)
            hint = ""
            if "CERTIFICATE" in reason.upper():
                hint = " / 社内CA証明書を OLLAMA_CA_BUNDLE に設定してください。"
            raise OllamaError(f"Ollama に接続できません ({url}): {reason}{hint}") from exc
        except TimeoutError as exc:
            raise OllamaError(f"Ollama の応答がタイムアウトしました ({self.timeout}秒)") from exc

    def health(self) -> dict:
        """接続確認と、利用可能なモデル一覧を返す。"""
        data = self._request("GET", "/api/tags")
        models = [m.get("name", "") for m in data.get("models", [])]
        return {
            "reachable": True,
            "model": self.model,
            "model_available": any(m == self.model or m.split(":")[0] == self.model for m in models),
            "models": models,
        }

    def chat(self, system: str, user: str, json_mode: bool = False) -> str:
        body: dict[str, Any] = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "stream": False,
            "options": {"temperature": settings.OLLAMA_TEMPERATURE},
        }
        if json_mode:
            body["format"] = "json"
        data = self._request("POST", "/api/chat", body)
        content = (data.get("message") or {}).get("content", "")
        if not content:
            raise OllamaError("Ollama から空の応答が返されました。モデル名を確認してください。")
        return content

    def chat_json(self, system: str, user: str) -> Any:
        """JSON 応答を期待するチャット。コードフェンス等が混ざっても抽出して返す。"""
        text = self.chat(system, user, json_mode=True)
        return extract_json(text)


def extract_json(text: str) -> Any:
    text = text.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    fence = re.search(r"```(?:json)?\s*(.*?)```", text, re.S)
    if fence:
        try:
            return json.loads(fence.group(1))
        except json.JSONDecodeError:
            pass
    for open_ch, close_ch in (("{", "}"), ("[", "]")):
        start, end = text.find(open_ch), text.rfind(close_ch)
        if start != -1 and end > start:
            try:
                return json.loads(text[start : end + 1])
            except json.JSONDecodeError:
                continue
    raise OllamaError("LLM の応答を JSON として解析できませんでした。")
