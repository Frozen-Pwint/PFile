"""
API のリクエスト/レスポンス定義(Pydantic)。FastAPI の /docs にこの内容が表示される。
FastAPI に依存しないため、単体でもテストできる。
"""
from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field


class RepoRequest(BaseModel):
    repo: Optional[str] = Field(None, description="レビュー対象の Git リポジトリのパス。省略時は DEFAULT_REPO_PATH")


class DiffRequest(RepoRequest):
    base: str = Field(..., examples=["origin/master"], description="PR のマージ先ブランチ")
    feature: str = Field(..., examples=["origin/feature/ISSUE-482-order-discount"], description="feature ブランチ")


class ChecklistRequest(DiffRequest):
    issue: str = Field("", examples=["482"], description="Issue 番号")
    title: str = Field("", examples=["受注取消に理由と値引率を追加"], description="PR タイトル")
    description: str = Field("", max_length=2000, description="Issue の内容(AI への補足)")
    use_llm: bool = Field(True, description="社内 Ollama で AI チェック項目を作成する")
    fetch: bool = Field(False, description="作成前に git fetch --prune origin を実行する")


class OllamaStatus(BaseModel):
    reachable: bool
    model: Optional[str] = None
    model_available: Optional[bool] = None
    models: list[str] = []
    error: Optional[str] = None


class HealthResponse(BaseModel):
    model: str
    ollama_url: str
    default_repo: str
    default_base: str
    ollama: OllamaStatus


class BranchRef(BaseModel):
    name: str
    date: str
    subject: str


class BranchList(BaseModel):
    current: str
    local: list[BranchRef]
    remote: list[BranchRef]


class ChangedFileRef(BaseModel):
    path: str
    old_path: Optional[str] = None
    status: str


class Commit(BaseModel):
    sha: str
    author: str
    date: str
    subject: str


class DiffFilesResponse(BaseModel):
    files: list[ChangedFileRef]
    commits: list[Commit]


class ChecklistItem(BaseModel):
    check: str
    category: str
    severity: Literal["high", "medium", "low"]
    reason: str
    file: Optional[str] = None
    lines: list[int]
    source: Literal["rule", "ai", "common"]
    rule_id: str
    idx: int


class ChangedFile(BaseModel):
    path: str
    old_path: Optional[str] = None
    status: str
    language: str
    additions: int
    deletions: int
    excluded: bool
    item_count: int


class ChecklistMeta(BaseModel):
    repo: str
    base: str
    feature: str
    base_sha: str
    feature_sha: str
    merge_base: str
    issue: str
    title: str
    generated_at: str
    model: Optional[str] = None
    file_count: int
    additions: int
    deletions: int
    commit_count: int


class ChecklistResult(BaseModel):
    meta: ChecklistMeta
    summary: str
    common_items: list[ChecklistItem]
    file_items: dict[str, list[ChecklistItem]]
    test_items: list[ChecklistItem]
    files: list[ChangedFile]
    commits: list[Commit]
    warnings: list[str]
    markdown: str
    file_name: str


class JobResponse(BaseModel):
    id: str
    status: Literal["running", "done", "error"]
    phase: str
    current: int
    total: int
    message: str
    elapsed_sec: float
    result: Optional[ChecklistResult] = None
    error: Optional[str] = None


class JobCreated(BaseModel):
    job_id: str


class FetchResponse(BaseModel):
    fetched: bool


class SavedChecklist(BaseModel):
    name: str
    size: int
    modified: str
