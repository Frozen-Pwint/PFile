"""
API の処理本体(Web フレームワーク非依存)。

FastAPI 版 (app/main.py) と標準ライブラリ版 (app/server.py) の両方から呼ばれる。
エラーは ApiError / GitCommandError / FileNotFoundError で送出し、
各サーバー側で {"error": "..."} 形式の JSON に変換する。
"""
from __future__ import annotations

from typing import Any

from . import git_diff as g
from .checklist import check_repo_allowed, generate_checklist, list_saved_checklists, read_saved_checklist
from .config import settings
from .jobs import jobs
from .ollama_client import OllamaClient, OllamaError


class ApiError(Exception):
    def __init__(self, status: int, message: str) -> None:
        super().__init__(message)
        self.status = status
        self.message = message


def _required(value: Any, name: str) -> str:
    v = str(value or "").strip()
    if not v:
        raise ApiError(400, f"'{name}' を指定してください。")
    return v


def resolve_repo(value: str | None) -> str:
    value = (value or settings.DEFAULT_REPO_PATH or "").strip()
    if not value:
        raise ApiError(400, "リポジトリのパスを指定してください。")
    return check_repo_allowed(value)


def health() -> dict:
    info: dict[str, Any] = {
        "model": settings.OLLAMA_CHAT_MODEL,
        "ollama_url": settings.OLLAMA_BASE_URL,
        "default_repo": settings.DEFAULT_REPO_PATH,
        "default_base": settings.DEFAULT_BASE_BRANCH,
    }
    try:
        info["ollama"] = OllamaClient(timeout=10).health()
    except OllamaError as e:
        info["ollama"] = {"reachable": False, "error": str(e)}
    return info


def branches(repo: str | None) -> dict:
    return g.list_branches(resolve_repo(repo))


def fetch(repo: str | None) -> dict:
    return {"fetched": g.fetch_remote(resolve_repo(repo), "origin")}


def diff_files(repo: str | None, base: str, feature: str) -> dict:
    repo_path = resolve_repo(repo)
    base, feature = _required(base, "base"), _required(feature, "feature")
    g.verify_repo(repo_path)
    g.verify_branch_exists(repo_path, base)
    g.verify_branch_exists(repo_path, feature)
    return {
        "files": g.get_changed_files(repo_path, base, feature),
        "commits": [c.__dict__ for c in g.get_commits(repo_path, base, feature)],
    }


def start_checklist(body: dict) -> dict:
    """チェックリスト作成ジョブを開始して job_id を返す(処理はバックグラウンド)。"""
    repo_path = resolve_repo(body.get("repo"))
    base = g.validate_ref_name(_required(body.get("base"), "base"))
    feature = g.validate_ref_name(_required(body.get("feature"), "feature"))
    if base == feature:
        raise ApiError(400, "マージ先ブランチと feature ブランチが同じです。")
    g.verify_repo(repo_path)
    if not body.get("fetch"):
        # fetch する場合は fetch 後に存在確認する(未取得のリモートブランチも指定できるように)
        g.verify_branch_exists(repo_path, base)
        g.verify_branch_exists(repo_path, feature)
    opts = dict(
        issue=str(body.get("issue") or "").strip().lstrip("#"),
        title=str(body.get("title") or "").strip(),
        description=str(body.get("description") or "").strip()[:2000],
        use_llm=bool(body.get("use_llm", True)),
        fetch=bool(body.get("fetch", False)),
    )
    job_id = jobs.submit(
        lambda progress: generate_checklist(repo_path, base, feature, progress=progress, **opts).to_dict()
    )
    return {"job_id": job_id}


def get_job(job_id: str) -> dict:
    job = jobs.get(job_id)
    if job is None:
        raise ApiError(404, "ジョブが見つかりません(サーバー再起動で消えた可能性があります)。")
    return job


def saved_list() -> list[dict]:
    return list_saved_checklists()


def saved_markdown(name: str) -> str:
    return read_saved_checklist(name)
