"""
ルールベースのチェック項目抽出。

LLM を使わなくても確実に出せる「差分の追加行に特定パターンがあれば確認項目を出す」
仕組み。LLM が使えない/遅いときのフォールバックであり、LLM の見落とし防止にもなる。
各ルールは 1 ファイルにつき 1 項目にまとめ、該当行番号を列挙する。

ルールを追加・調整したい場合は RULES に Rule を追加するだけでよい。
"""
from __future__ import annotations

import fnmatch
import re
from dataclasses import dataclass
from pathlib import PurePosixPath
from typing import Callable, Optional

from .git_diff import FileDiff
from .models import ChecklistItem


@dataclass
class Rule:
    id: str
    languages: tuple[str, ...]        # 対象言語(detect_language の値)。"*" は全て
    pattern: re.Pattern               # 追加行に対する正規表現
    check: str
    category: str
    severity: str
    reason: str
    exclude: Optional[re.Pattern] = None   # 一致した行を除外する正規表現
    path_glob: Optional[str] = None        # ファイル名で絞り込む場合


def _r(p: str) -> re.Pattern:
    return re.compile(p, re.IGNORECASE)


RULES: list[Rule] = [
    # ------------------------------------------------------------------ C#
    Rule("CS-SQL-CONCAT", ("csharp",),
         _r(r'(\b(select|insert|update|delete)\b[^"]*"\s*\+)|(\+\s*"\s*(where|and|or|values|set)\b)|(\$@?"[^"]*\b(select|insert|update|delete)\b[^"]*\{)'),
         "SQL を文字列連結/補間で組み立てていないか(パラメータ化クエリになっているか)",
         "セキュリティ", "high", "SQL インジェクションの典型的な原因になるため。"),
    Rule("CS-SECRET", ("csharp", "json", "config"),
         _r(r'(password|pwd|passwd|secret|apikey|api_key|connectionstring)\s*["\']?\s*[:=]\s*["\'][^"\']{3,}'),
         "パスワード・接続文字列・APIキーがハードコードされていないか",
         "セキュリティ", "high", "リポジトリに機密情報が残ると漏えいにつながるため。"),
    Rule("CS-EMPTY-CATCH", ("csharp",), _r(r'catch\s*(\([^)]*\))?\s*\{\s*\}'),
         "空の catch で例外を握りつぶしていないか",
         "エラー処理", "high", "障害の原因が追えなくなり、データ不整合を見逃すため。"),
    Rule("CS-CATCH-ALL", ("csharp",), _r(r'catch\s*\(\s*(System\.)?Exception\b'),
         "Exception の一括 catch でログ出力・再スロー・ユーザー通知が適切に行われているか",
         "エラー処理", "medium", "想定外の例外まで同じ扱いになり、原因の切り分けが難しくなるため。"),
    Rule("CS-ASYNC-VOID", ("csharp",), _r(r'\basync\s+void\b'),
         "async void を使っていないか(イベントハンドラー以外は async Task にする)",
         "信頼性", "high", "例外が呼び出し元で捕捉できず、プロセスが落ちる可能性があるため。"),
    Rule("CS-SYNC-OVER-ASYNC", ("csharp",), _r(r'\.(Result|Wait\(\)|GetAwaiter\(\)\.GetResult\(\))'),
         ".Result / .Wait() で非同期処理を同期待ちしていないか",
         "性能", "medium", "デッドロックやスレッド枯渇の原因になるため。"),
    Rule("CS-FLOAT-MONEY", ("csharp",), _r(r'\b(double|float)\b'),
         "金額・数量・単価に double/float を使っていないか(decimal を使う)",
         "業務ロジック", "medium", "浮動小数点の誤差で金額計算がずれるため(ERP では特に重要)。"),
    Rule("CS-ROUND", ("csharp",), _r(r'Math\.(Round|Floor|Ceiling|Truncate)\s*\('),
         "端数処理(丸め方式・桁数・MidpointRounding)が業務仕様どおりか",
         "業務ロジック", "medium", "Math.Round の既定は銀行丸めで、四捨五入とは結果が異なるため。"),
    Rule("CS-DATETIME-NOW", ("csharp",), _r(r'\bDateTime\.(Now|Today)\b'),
         "DateTime.Now/Today の使用がタイムゾーン・締め日・テスト容易性の観点で問題ないか",
         "業務ロジック", "low", "サーバーのタイムゾーン依存や日付境界の不具合が起きやすいため。"),
    Rule("CS-TRANSACTION", ("csharp",), _r(r'(BeginTransaction|TransactionScope|SaveChanges(Async)?\s*\(|ExecuteNonQuery|ExecuteSqlRaw)'),
         "更新処理のトランザクション範囲・コミット/ロールバックが正しいか",
         "データ整合性", "medium", "途中失敗時に伝票・在庫などのデータが中途半端に更新されないようにするため。"),
    Rule("CS-DISPOSE", ("csharp",), _r(r'new\s+(SqlConnection|SqlCommand|OracleConnection|StreamReader|StreamWriter|FileStream|HttpClient)\s*\('),
         "IDisposable なオブジェクトを using で解放しているか(HttpClient は使い回しているか)",
         "信頼性", "medium", "接続・ファイルハンドル・ソケットのリークを防ぐため。"),
    Rule("CS-ENDPOINT", ("csharp",), _r(r'\[\s*(Http(Get|Post|Put|Delete|Patch)|Route)\b'),
         "追加/変更した API に認可([Authorize]/権限チェック)と入力検証があるか",
         "セキュリティ", "medium", "権限のないユーザーによる参照・更新を防ぐため。"),
    Rule("CS-ALLOW-ANON", ("csharp",), _r(r'\[\s*AllowAnonymous\s*\]'),
         "[AllowAnonymous] の付与が本当に必要か",
         "セキュリティ", "high", "認証なしでアクセスできる口が増えるため。"),
    Rule("CS-THREAD-SLEEP", ("csharp",), _r(r'Thread\.Sleep\s*\('),
         "Thread.Sleep を使っていないか(await Task.Delay 等に置き換えられないか)",
         "性能", "medium", "スレッドを占有し、スループットが落ちるため。"),
    Rule("CS-DEBUG-OUT", ("csharp",), _r(r'\b(Console|Debug)\.Write(Line)?\s*\('),
         "デバッグ用の Console/Debug 出力が残っていないか(ロガーを使う)",
         "保守性", "low", "本番ログに残らない/不要な出力が混ざるため。"),
    Rule("CS-QUERY-IN-LOOP", ("csharp",), _r(r'^\s*(foreach|for|while)\s*\('),
         "ループ内で DB アクセスや API 呼び出しをしていないか(N+1 になっていないか)",
         "性能", "low", "明細件数が多い ERP データで処理時間が急増するため。"),

    # -------------------------------------------------------- Angular / TS
    Rule("TS-SUBSCRIBE", ("typescript",), _r(r'\.subscribe\s*\('),
         "subscribe の購読解除(takeUntilDestroyed / async パイプ等)ができているか",
         "信頼性", "medium", "画面遷移後も購読が残り、メモリリークや二重処理の原因になるため。"),
    Rule("TS-HTTP-ERROR", ("typescript",), _r(r'\bhttp(Client)?\.(get|post|put|delete|patch)\s*[<(]'),
         "HTTP 呼び出しのエラー処理(catchError・エラーメッセージ表示)があるか",
         "エラー処理", "medium", "通信エラー時に画面が固まる・無反応になるのを防ぐため。"),
    Rule("TS-ANY", ("typescript",), _r(r'(:\s*any\b|\bas\s+any\b|<any>)'),
         "any 型を使っていないか(インターフェース/型を定義する)",
         "保守性", "low", "型チェックが効かず、項目名の変更などで実行時エラーになりやすいため。"),
    Rule("TS-CONSOLE", ("typescript",), _r(r'\bconsole\.(log|debug|info)\s*\('),
         "console.log などのデバッグコードが残っていないか",
         "保守性", "low", "ブラウザコンソールに業務データが出力される可能性があるため。"),
    Rule("TS-BYPASS", ("typescript",), _r(r'bypassSecurityTrust|\.innerHTML\s*=|document\.write'),
         "サニタイズを回避した HTML 挿入をしていないか",
         "セキュリティ", "high", "XSS の原因になるため。"),
    Rule("TS-DOM", ("typescript",), _r(r'(nativeElement|document\.(getElementById|querySelector))'),
         "DOM を直接操作していないか(テンプレート/Renderer2 で代替できないか)",
         "保守性", "low", "Angular の変更検知と競合し、不具合の原因になるため。"),
    Rule("TS-STORAGE", ("typescript",), _r(r'\b(localStorage|sessionStorage)\b'),
         "localStorage/sessionStorage に機密情報(トークン・個人情報)を保存していないか",
         "セキュリティ", "medium", "XSS 発生時に容易に盗まれるため。"),
    Rule("TS-TIMER", ("typescript",), _r(r'\b(setTimeout|setInterval)\s*\('),
         "setTimeout/setInterval を破棄時にクリアしているか、タイミング依存の実装になっていないか",
         "信頼性", "low", "画面破棄後に処理が走る・環境によって動作が変わるのを防ぐため。"),
    Rule("TS-NUMBER-CALC", ("typescript",), _r(r'(parseFloat|toFixed\s*\(|Number\s*\()'),
         "画面側の金額・数量計算で浮動小数点誤差や丸めの不一致が起きないか(サーバー側と一致するか)",
         "業務ロジック", "medium", "画面表示とサーバー計算の結果がずれると請求額などの不整合になるため。"),

    # ---------------------------------------------------------------- HTML
    Rule("HTML-INNERHTML", ("html",), _r(r'\[innerHTML\]'),
         "[innerHTML] に信頼できない値をバインドしていないか",
         "セキュリティ", "high", "XSS の原因になるため。"),
    Rule("HTML-NGFOR-TRACK", ("html",), _r(r'\*ngFor\s*='),
         "*ngFor に trackBy を指定しているか(大量明細の一覧)",
         "性能", "low", "一覧更新時に全行が再描画され、明細の多い画面が重くなるため。",
         exclude=_r(r'trackBy')),
    Rule("HTML-IMG-ALT", ("html",), _r(r'<img\b'),
         "img に alt 属性があるか",
         "アクセシビリティ", "low", "読み上げ・画像未表示時に内容が伝わらないため。",
         exclude=_r(r'\balt\s*=')),
    Rule("HTML-FORM-INPUT", ("html",), _r(r'<(input|select|textarea)\b'),
         "入力項目にラベル・必須/桁数/形式のバリデーションとエラーメッセージがあるか",
         "入力検証", "medium", "不正値の登録や、ユーザーが入力誤りに気付けない状態を防ぐため。"),
    Rule("HTML-INLINE-STYLE", ("html",), _r(r'\sstyle\s*='),
         "インラインスタイルを使っていないか(CSS クラスに寄せる)",
         "保守性", "low", "画面ごとに見た目がばらつき、修正漏れが起きやすいため。"),
    Rule("HTML-BUTTON-TYPE", ("html",), _r(r'<button\b'),
         "button に type 属性があり、二重クリック(二重登録)対策がされているか",
         "業務ロジック", "medium", "form 内の button は既定で submit になり、二重登録の原因になるため。",
         exclude=_r(r'\btype\s*=')),

    # ----------------------------------------------------------------- CSS
    Rule("CSS-IMPORTANT", ("css",), _r(r'!important'),
         "!important を使っていないか",
         "保守性", "low", "スタイルの上書き関係が複雑になるため。"),
    Rule("CSS-NG-DEEP", ("css",), _r(r'::ng-deep|/deep/|>>>'),
         "::ng-deep の影響範囲が意図した画面/コンポーネントに限定されているか",
         "保守性", "medium", "非推奨で、他画面のスタイルまで変えてしまうことがあるため。"),
    Rule("CSS-HARDCODED-COLOR", ("css",), _r(r'#[0-9a-f]{3,8}\b|rgba?\('),
         "色を直書きせず、共通の変数/テーマを使っているか",
         "保守性", "low", "画面ごとに色がばらつき、テーマ変更時に修正漏れが出るため。",
         exclude=_r(r'^\s*--')),
    Rule("CSS-ZINDEX", ("css",), _r(r'z-index\s*:'),
         "z-index が他のダイアログ・ドロップダウンと競合しないか",
         "UI", "low", "モーダルやメニューが隠れる不具合が起きやすいため。"),

    # ----------------------------------------------------------------- SQL
    Rule("SQL-DESTRUCTIVE", ("sql",), _r(r'\b(drop\s+(table|column|index|view|procedure)|truncate\s+table|alter\s+table\s+\S+\s+drop)\b'),
         "削除系 DDL(DROP/TRUNCATE)の影響範囲と、バックアップ・ロールバック手順があるか",
         "データ整合性", "high", "本番データを失う可能性があるため。"),
    Rule("SQL-DELETE-UPDATE", ("sql",), _r(r'^\s*(delete\s+from|update\s+\S+\s+set)\b'),
         "UPDATE/DELETE に正しい WHERE 条件があり、対象件数を事前確認しているか",
         "データ整合性", "high", "全件更新・全件削除事故を防ぐため。"),
    Rule("SQL-ALTER", ("sql",), _r(r'\balter\s+table\b'),
         "テーブル定義変更に合わせてエンティティ/DTO/画面項目が更新されているか、既存データへの影響はないか",
         "データ整合性", "medium", "定義とプログラムの不一致は実行時エラーになるため。"),
    Rule("SQL-SELECT-STAR", ("sql", "csharp"), _r(r'select\s+\*'),
         "SELECT * を使っていないか(必要な列を明示する)",
         "性能", "low", "列追加時の影響や不要なデータ転送を避けるため。"),

    # -------------------------------------------------------- 共通(全言語)
    Rule("ANY-TODO", ("*",), _r(r'\b(TODO|FIXME|HACK|XXX)\b'),
         "TODO/FIXME が残っていないか(残す場合は Issue 化されているか)",
         "保守性", "low", "対応漏れのままリリースされるのを防ぐため。"),
    Rule("ANY-COMMENTED-CODE", ("csharp", "typescript"), _r(r'^\s*//\s*(var|let|const|if|for|return|public|private|this\.)\b'),
         "コメントアウトされたコードが残っていないか",
         "保守性", "low", "不要コードは Git 履歴で追えるため削除する。"),
]


def _match_exclude(path: str, patterns: list[str]) -> bool:
    p = path.replace("\\", "/")
    name = PurePosixPath(p).name
    return any(fnmatch.fnmatch(p, pat) or fnmatch.fnmatch(name, pat) for pat in patterns)


def is_excluded(path: str, patterns: list[str]) -> bool:
    return _match_exclude(path, patterns)


def _apply_line_rules(fd: FileDiff) -> list[ChecklistItem]:
    items: list[ChecklistItem] = []
    added = fd.added_lines
    for rule in RULES:
        if "*" not in rule.languages and fd.language not in rule.languages:
            continue
        if rule.path_glob and not fnmatch.fnmatch(fd.path, rule.path_glob):
            continue
        hit_lines = [
            l.new_lineno for l in added
            if l.new_lineno is not None
            and rule.pattern.search(l.content)
            and not (rule.exclude and rule.exclude.search(l.content))
        ]
        if hit_lines:
            items.append(ChecklistItem(
                check=rule.check, category=rule.category, severity=rule.severity,
                reason=rule.reason, file=fd.path, lines=hit_lines[:10],
                source="rule", rule_id=rule.id,
            ))
    return items


_PUBLIC_SIG_RE = re.compile(r'^\s*public\s+(?!class|interface|enum|record|struct)[\w<>\[\],\s?]+\s+\w+\s*\(')


def _file_level_items(fd: FileDiff, all_paths: set[str]) -> list[ChecklistItem]:
    items: list[ChecklistItem] = []
    name = PurePosixPath(fd.path).name.lower()

    if fd.status == "deleted":
        items.append(ChecklistItem(
            "削除したファイルを参照している箇所(import/using/DI 登録/ルーティング)が残っていないか",
            "影響範囲", "medium", "参照が残るとビルドエラーや実行時エラーになるため。",
            file=fd.path, rule_id="FILE-DELETED"))
    if fd.status == "renamed":
        items.append(ChecklistItem(
            f"名前変更({fd.old_path} → {fd.path})に伴う参照・設定・ドキュメントの更新漏れがないか",
            "影響範囲", "low", "旧名での参照が残っていないか確認するため。",
            file=fd.path, rule_id="FILE-RENAMED"))

    # C#: 公開メソッドのシグネチャ変更(削除行に public メソッド定義がある)
    if fd.language == "csharp" and fd.status != "added":
        removed_sigs = [l.old_lineno for l in fd.deleted_lines if _PUBLIC_SIG_RE.match(l.content)]
        if removed_sigs:
            items.append(ChecklistItem(
                "public メソッドのシグネチャ変更・削除が、他モジュール/画面/バッチの呼び出し元に影響しないか",
                "影響範囲", "medium", "ERP では複数機能から共通処理が呼ばれていることが多いため。",
                file=fd.path, lines=[], source="rule", rule_id="CS-PUBLIC-API"))

    # Angular: コンポーネント/サービス追加時にテストがあるか
    if fd.status == "added" and re.search(r'\.(component|service|pipe|guard|directive)\.ts$', name):
        spec = re.sub(r'\.ts$', '.spec.ts', fd.path)
        if spec not in all_paths:
            items.append(ChecklistItem(
                "新規追加したクラスの単体テスト(.spec.ts)が用意されているか",
                "テスト", "medium", f"{PurePosixPath(spec).name} が差分に含まれていないため。",
                file=fd.path, rule_id="NG-NO-SPEC"))
    if re.search(r'(-routing\.module\.ts|\.routes\.ts|app\.routes\.ts)$', name):
        items.append(ChecklistItem(
            "ルーティング変更に権限ガード(canActivate 等)とメニュー・パンくずの更新が反映されているか",
            "セキュリティ", "medium", "URL 直打ちで権限外の画面が開けてしまうのを防ぐため。",
            file=fd.path, rule_id="NG-ROUTING"))

    # 設定・依存関係
    if name.startswith("appsettings") or name in ("web.config", "app.config") or re.match(r'environment(\..+)?\.ts$', name):
        items.append(ChecklistItem(
            "設定値の変更が全環境(開発/検証/本番)の設定ファイル・デプロイ手順に反映されているか",
            "リリース", "medium", "環境ごとの設定漏れは本番障害の典型的な原因のため。",
            file=fd.path, rule_id="CFG-ENV"))
    if name == "package.json":
        items.append(ChecklistItem(
            "追加/更新したパッケージのバージョン・ライセンス・脆弱性(npm audit)を確認したか",
            "依存関係", "medium", "社内利用可否と既知の脆弱性を確認するため。",
            file=fd.path, rule_id="DEP-NPM"))
    if name.endswith(".csproj") or name == "packages.config" or name == "directory.packages.props":
        items.append(ChecklistItem(
            "NuGet パッケージ・ターゲットフレームワーク変更の影響(ビルドサーバー・他プロジェクト)を確認したか",
            "依存関係", "medium", "依存関係の変更はビルド・デプロイ環境にも影響するため。",
            file=fd.path, rule_id="DEP-NUGET"))
    if fd.language == "sql" or re.search(r'(migrations?/|\.sql$)', fd.path, re.IGNORECASE):
        items.append(ChecklistItem(
            "DB 変更スクリプトのリリース手順(実行順・再実行可否・ロールバック)が用意されているか",
            "リリース", "high", "DB 変更はアプリのデプロイと順序を合わせる必要があるため。",
            file=fd.path, rule_id="DB-MIGRATION"))
    return items


def analyze_file(fd: FileDiff, all_paths: set[str]) -> list[ChecklistItem]:
    """1 ファイル分のルールベースのチェック項目を返す。"""
    return _file_level_items(fd, all_paths) + _apply_line_rules(fd)


def common_items(files: list[FileDiff]) -> list[ChecklistItem]:
    """PR 全体に対する共通チェック項目(変更内容に応じて出し分け)。"""
    langs = {f.language for f in files}
    paths = [f.path for f in files]
    items = [
        ChecklistItem("Issue の要件・受け入れ条件をすべて満たしているか", "要件", "high",
                      "PR の目的を満たしていることを最初に確認するため。", source="common", rule_id="C-ISSUE"),
        ChecklistItem("マージ先ブランチの最新を取り込み、コンフリクトがないか", "リリース", "medium",
                      "マージ時の衝突・デグレを防ぐため。", source="common", rule_id="C-REBASE"),
        ChecklistItem("PR の説明に変更内容・影響範囲・テスト結果・関連 Issue 番号が記載されているか", "レビュー", "low",
                      "レビュアーと後から見る人が変更意図を追えるようにするため。", source="common", rule_id="C-PRDESC"),
    ]
    if "csharp" in langs:
        items.append(ChecklistItem("dotnet build / 既存の単体テストがエラー・新規警告なしで通るか", "ビルド", "high",
                                   "C# の変更が含まれるため。", source="common", rule_id="C-DOTNET"))
    if langs & {"typescript", "html", "css", "typescript-test"}:
        items.append(ChecklistItem("ng build / ng lint / ng test がエラーなしで通るか", "ビルド", "high",
                                   "Angular の変更が含まれるため。", source="common", rule_id="C-NG"))
        items.append(ChecklistItem("対象ブラウザ・画面サイズで表示崩れがないか、変更画面のスクリーンショットを PR に添付したか",
                                   "UI", "medium", "画面の変更が含まれるため。", source="common", rule_id="C-UI"))
    if "csharp" in langs and langs & {"typescript", "html"}:
        items.append(ChecklistItem("API の入出力(DTO の項目名・型・必須)がフロントとバックエンドで一致しているか",
                                   "影響範囲", "medium", "C# と Angular の両方に変更があるため。", source="common", rule_id="C-CONTRACT"))
    if "sql" in langs or any(re.search(r'migrations?/', p, re.I) for p in paths):
        items.append(ChecklistItem("DB 変更を検証環境で実行し、既存データで動作確認したか", "データ整合性", "high",
                                   "DB 変更が含まれるため。", source="common", rule_id="C-DB"))
    has_tests = any(f.language == "typescript-test" or re.search(r'(tests?/|\.Tests?/|Tests?\.cs$)', f.path) for f in files)
    if not has_tests:
        items.append(ChecklistItem("テストコードの追加・更新が不要である理由が説明されているか", "テスト", "medium",
                                   "差分にテストコードが含まれていないため。", source="common", rule_id="C-NOTEST"))
    return items
