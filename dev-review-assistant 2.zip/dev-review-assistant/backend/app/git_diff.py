"""
Git 差分比較モジュール。

PR のマージ先ブランチ(例: origin/master, origin/develop)と feature ブランチの
差分を取得し、ファイル単位・ハンク単位の構造体に変換する。

GitPython 等には依存せず、git CLI を subprocess で呼び出す。
差分は 3 点リーダー (base...feature) = マージベース基準で取るため、
PR 画面に表示される「feature 側で行った変更」だけが対象になる。
"""
from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


class GitCommandError(RuntimeError):
    """git コマンド実行に失敗した場合の例外。"""


LANGUAGE_BY_EXTENSION = {
    ".cs": "csharp",
    ".csproj": "msbuild",
    ".config": "config",
    ".ts": "typescript",
    ".html": "html",
    ".htm": "html",
    ".cshtml": "html",
    ".css": "css",
    ".scss": "css",
    ".less": "css",
    ".json": "json",
    ".sql": "sql",
    ".js": "typescript",
    ".xml": "config",
    ".yml": "config",
    ".yaml": "config",
}


def detect_language(file_path: str) -> str:
    p = Path(file_path)
    name = p.name.lower()
    if name.endswith(".spec.ts"):
        return "typescript-test"
    return LANGUAGE_BY_EXTENSION.get(p.suffix.lower(), "other")


def run_git(repo_path: str, args: list[str], timeout: int = 120) -> str:
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=repo_path,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
        )
    except FileNotFoundError as exc:
        raise GitCommandError("git コマンドが見つかりません。git をインストールしてください。") from exc
    except subprocess.TimeoutExpired as exc:
        raise GitCommandError(f"git コマンドがタイムアウトしました: git {' '.join(args)}") from exc
    if result.returncode != 0:
        raise GitCommandError(f"git {' '.join(args)} が失敗しました: {result.stderr.strip()}")
    return result.stdout


def verify_repo(repo_path: str) -> None:
    if not repo_path or not Path(repo_path).is_dir():
        raise GitCommandError(f"リポジトリパスが存在しません: {repo_path}")
    try:
        run_git(repo_path, ["rev-parse", "--is-inside-work-tree"])
    except GitCommandError as exc:
        raise GitCommandError(f"git リポジトリではありません: {repo_path}") from exc


def verify_branch_exists(repo_path: str, branch: str) -> None:
    validate_ref_name(branch)
    try:
        run_git(repo_path, ["rev-parse", "--verify", "--quiet", f"{branch}^{{commit}}"])
    except GitCommandError as exc:
        raise GitCommandError(
            f"ブランチ '{branch}' が見つかりません。リモートブランチの場合は 'origin/xxx' 形式で指定し、fetch 済みか確認してください。"
        ) from exc


_SAFE_REF_RE = re.compile(r"^[A-Za-z0-9._/\-@]+$")


def validate_ref_name(ref: str) -> str:
    """ブランチ名を検証する('-' 始まりによる git オプション注入などを防止)。"""
    ref = (ref or "").strip()
    if not ref or ref.startswith("-") or ".." in ref or not _SAFE_REF_RE.match(ref):
        raise GitCommandError(f"不正なブランチ名です: '{ref}'")
    return ref


def fetch_remote(repo_path: str, remote: str = "origin") -> bool:
    """`git fetch --prune <remote>`。リモート未設定のリポジトリでは何もせず False を返す。"""
    verify_repo(repo_path)
    validate_ref_name(remote)
    remotes = run_git(repo_path, ["remote"]).split()
    if remote not in remotes:
        return False
    run_git(repo_path, ["fetch", "--prune", remote], timeout=300)
    return True


def list_branches(repo_path: str) -> dict:
    """ローカル/リモート追跡ブランチ一覧(更新日時の新しい順)と現在のブランチを返す。"""
    verify_repo(repo_path)
    out = run_git(
        repo_path,
        [
            "for-each-ref",
            "--sort=-committerdate",
            "--format=%(refname)%1f%(refname:short)%1f%(committerdate:short)%1f%(subject)",
            "refs/heads",
            "refs/remotes",
        ],
    )
    local, remote = [], []
    for line in out.splitlines():
        parts = line.split("\x1f")
        if len(parts) != 4:
            continue
        full, short, date, subject = parts
        if full.endswith("/HEAD"):
            continue
        entry = {"name": short, "date": date, "subject": subject}
        (remote if full.startswith("refs/remotes/") else local).append(entry)
    try:
        current = run_git(repo_path, ["rev-parse", "--abbrev-ref", "HEAD"]).strip()
    except GitCommandError:
        current = ""
    return {"current": current, "local": local, "remote": remote}


def short_sha(repo_path: str, ref: str) -> str:
    return run_git(repo_path, ["rev-parse", "--short", f"{ref}^{{commit}}"]).strip()


def merge_base(repo_path: str, base: str, feature: str) -> str:
    try:
        return run_git(repo_path, ["merge-base", base, feature]).strip()[:10]
    except GitCommandError:
        return ""


@dataclass
class DiffLine:
    kind: str  # "context" | "add" | "del"
    content: str
    old_lineno: Optional[int]
    new_lineno: Optional[int]


@dataclass
class DiffHunk:
    header: str
    old_start: int
    old_lines: int
    new_start: int
    new_lines: int
    lines: list[DiffLine] = field(default_factory=list)


@dataclass
class FileDiff:
    path: str
    old_path: Optional[str]
    status: str  # added | modified | deleted | renamed | copied
    language: str
    raw_diff: str = ""
    hunks: list[DiffHunk] = field(default_factory=list)
    additions: int = 0
    deletions: int = 0
    is_binary: bool = False

    @property
    def added_lines(self) -> list[DiffLine]:
        return [l for h in self.hunks for l in h.lines if l.kind == "add"]

    @property
    def deleted_lines(self) -> list[DiffLine]:
        return [l for h in self.hunks for l in h.lines if l.kind == "del"]


@dataclass
class CommitInfo:
    sha: str
    author: str
    date: str
    subject: str


_HUNK_HEADER_RE = re.compile(
    r"^@@ -(?P<os>\d+)(?:,(?P<ol>\d+))? \+(?P<ns>\d+)(?:,(?P<nl>\d+))? @@"
)
_STATUS_MAP = {"A": "added", "M": "modified", "D": "deleted", "R": "renamed", "C": "copied", "T": "modified"}


def get_changed_files(repo_path: str, base: str, feature: str) -> list[dict]:
    output = run_git(repo_path, ["diff", "--name-status", "-M", f"{base}...{feature}"])
    files = []
    for line in output.splitlines():
        if not line.strip():
            continue
        parts = line.split("\t")
        code = parts[0][0]
        status = _STATUS_MAP.get(code, "modified")
        if code in ("R", "C") and len(parts) == 3:
            files.append({"path": parts[2], "old_path": parts[1], "status": status})
        else:
            files.append({"path": parts[-1], "old_path": None, "status": status})
    return files


def get_file_diff_text(repo_path: str, base: str, feature: str, file_path: str) -> str:
    return run_git(repo_path, ["diff", "-M", "--unified=3", f"{base}...{feature}", "--", file_path])


def get_commits(repo_path: str, base: str, feature: str, limit: int = 50) -> list[CommitInfo]:
    out = run_git(
        repo_path,
        ["log", f"--max-count={limit}", "--no-merges", "--format=%h%x1f%an%x1f%ad%x1f%s", "--date=short", f"{base}..{feature}"],
    )
    commits = []
    for line in out.splitlines():
        parts = line.split("\x1f")
        if len(parts) == 4:
            commits.append(CommitInfo(*parts))
    return commits


def parse_unified_diff(diff_text: str) -> list[DiffHunk]:
    hunks: list[DiffHunk] = []
    current: Optional[DiffHunk] = None
    old_no = new_no = 0
    for raw in diff_text.splitlines():
        m = _HUNK_HEADER_RE.match(raw)
        if m:
            current = DiffHunk(
                header=raw,
                old_start=int(m.group("os")),
                old_lines=int(m.group("ol") or "1"),
                new_start=int(m.group("ns")),
                new_lines=int(m.group("nl") or "1"),
            )
            hunks.append(current)
            old_no, new_no = current.old_start, current.new_start
            continue
        if current is None:
            continue  # diff --git / index / --- / +++ のメタ行
        if raw.startswith("+"):
            current.lines.append(DiffLine("add", raw[1:], None, new_no))
            new_no += 1
        elif raw.startswith("-"):
            current.lines.append(DiffLine("del", raw[1:], old_no, None))
            old_no += 1
        elif raw.startswith("\\"):
            continue  # "\ No newline at end of file"
        else:
            current.lines.append(DiffLine("context", raw[1:] if raw.startswith(" ") else raw, old_no, new_no))
            old_no += 1
            new_no += 1
    return hunks


def get_full_diff(repo_path: str, base: str, feature: str) -> list[FileDiff]:
    """base...feature 間の全変更ファイルの構造化差分を返す。"""
    verify_repo(repo_path)
    verify_branch_exists(repo_path, base)
    verify_branch_exists(repo_path, feature)
    result: list[FileDiff] = []
    for entry in get_changed_files(repo_path, base, feature):
        text = get_file_diff_text(repo_path, base, feature, entry["path"])
        hunks = parse_unified_diff(text)
        fd = FileDiff(
            path=entry["path"],
            old_path=entry["old_path"],
            status=entry["status"],
            language=detect_language(entry["path"]),
            raw_diff=text,
            hunks=hunks,
            is_binary="Binary files" in text and not hunks,
        )
        fd.additions = len(fd.added_lines)
        fd.deletions = len(fd.deleted_lines)
        result.append(fd)
    return result
