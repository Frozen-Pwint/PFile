"""
開発者サポートAI - PR チェックリスト API (FastAPI 版)。

起動:
    cd backend
    pip install -r requirements.txt
    uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
    (または python -m app.main)

API ドキュメント:  http://localhost:8000/docs  (Swagger UI)

pip install ができない環境では、同じ API を標準ライブラリだけで提供する
`python -m app.server` を使う(処理本体は app/services.py で共通)。
"""
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, Query, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles

from . import git_diff as g
from . import services
from .config import settings
from .schemas import (BranchList, ChecklistRequest, DiffFilesResponse, DiffRequest, FetchResponse,
                      HealthResponse, JobCreated, JobResponse, RepoRequest, SavedChecklist)
from .services import ApiError

app = FastAPI(
    title="開発者サポートAI - PR チェックリスト API",
    description="PR のマージ先ブランチ(origin 側)と feature ブランチの差分から、"
                "ルールベースと社内 Ollama の GPT でレビュー用チェックリスト(Markdown)を作成します。",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type"],
)


# ---------------------------------------------------------------------------
# エラーは画面側(Angular)が扱いやすいよう {"error": "..."} に統一する
# ---------------------------------------------------------------------------

@app.exception_handler(ApiError)
async def _api_error(_: Request, exc: ApiError) -> JSONResponse:
    return JSONResponse({"error": exc.message}, status_code=exc.status)


@app.exception_handler(g.GitCommandError)
async def _git_error(_: Request, exc: g.GitCommandError) -> JSONResponse:
    return JSONResponse({"error": str(exc)}, status_code=400)


@app.exception_handler(FileNotFoundError)
async def _not_found(_: Request, __: FileNotFoundError) -> JSONResponse:
    return JSONResponse({"error": "見つかりません。"}, status_code=404)


@app.exception_handler(RequestValidationError)
async def _validation_error(_: Request, exc: RequestValidationError) -> JSONResponse:
    fields = ", ".join(".".join(str(p) for p in e.get("loc", [])[1:]) or "body" for e in exc.errors())
    return JSONResponse({"error": f"入力内容が正しくありません: {fields}"}, status_code=422)


# ---------------------------------------------------------------------------
# API
# git / Ollama 呼び出しはブロッキング処理のため、通常の def で定義する
# (FastAPI がスレッドプールで実行する)。
# ---------------------------------------------------------------------------

@app.get("/api/health", response_model=HealthResponse, tags=["system"], summary="社内 Ollama の接続確認・設定")
def health():
    return services.health()


@app.get("/api/branches", response_model=BranchList, tags=["git"], summary="ブランチ一覧")
def branches(repo: Optional[str] = Query(None, description="リポジトリのパス")):
    return services.branches(repo)


@app.post("/api/git/fetch", response_model=FetchResponse, tags=["git"], summary="git fetch --prune origin")
def git_fetch(req: RepoRequest):
    return services.fetch(req.repo)


@app.post("/api/diff/files", response_model=DiffFilesResponse, tags=["git"], summary="PR の変更ファイルとコミット")
def diff_files(req: DiffRequest):
    return services.diff_files(req.repo, req.base, req.feature)


@app.post("/api/checklists", response_model=JobCreated, status_code=202, tags=["checklist"],
          summary="チェックリスト作成を開始(ジョブ ID を返す)")
def create_checklist(req: ChecklistRequest):
    return services.start_checklist(req.model_dump())


@app.get("/api/jobs/{job_id}", response_model=JobResponse, tags=["checklist"], summary="作成ジョブの進捗・結果")
def get_job(job_id: str):
    return services.get_job(job_id)


@app.get("/api/checklists", response_model=list[SavedChecklist], tags=["checklist"], summary="保存済みチェックリスト一覧")
def saved_list():
    return services.saved_list()


@app.get("/api/checklists/{name}", response_class=PlainTextResponse, tags=["checklist"],
         summary="保存済みチェックリスト(Markdown)")
def saved_markdown(name: str, download: bool = Query(False, description="true でファイルとしてダウンロード")):
    text = services.saved_markdown(name)
    headers = {}
    if download:
        from urllib.parse import quote
        headers["Content-Disposition"] = f"attachment; filename*=UTF-8''{quote(name)}"
    return PlainTextResponse(text, media_type="text/markdown; charset=utf-8", headers=headers)


@app.get("/api/{rest:path}", include_in_schema=False)
def api_not_found(rest: str):
    raise ApiError(404, "API が見つかりません。")


# ---------------------------------------------------------------------------
# 画面配信: Angular を ng build した成果物があれば同じポートで配信する
# ---------------------------------------------------------------------------
_static = Path(settings.STATIC_DIR)
if _static.is_dir():
    app.mount("/", StaticFiles(directory=str(_static), html=True), name="ui")
else:
    @app.get("/", include_in_schema=False)
    def root() -> PlainTextResponse:
        return PlainTextResponse(
            "開発者サポートAI API (FastAPI) は起動しています。API ドキュメント: /docs\n"
            "画面は frontend で npm start するか、ng build して STATIC_DIR に配置してください。"
        )


def run() -> None:
    import uvicorn

    print(f"開発者サポートAI API (FastAPI): http://{settings.HOST}:{settings.PORT}/docs  "
          f"(Ollama: {settings.OLLAMA_BASE_URL}, model: {settings.OLLAMA_CHAT_MODEL})")
    uvicorn.run("app.main:app", host=settings.HOST, port=settings.PORT)


if __name__ == "__main__":
    run()
