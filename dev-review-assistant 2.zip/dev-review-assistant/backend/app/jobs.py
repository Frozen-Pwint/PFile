"""
バックグラウンドジョブ管理(標準ライブラリのみ)。

AI レビューはファイル数に応じて数分かかるため、HTTP リクエストはジョブ ID を
すぐ返し、画面側は /api/jobs/{id} をポーリングして進捗を表示する。
"""
from __future__ import annotations

import threading
import time
import traceback
import uuid
from typing import Any, Callable


class JobManager:
    def __init__(self, keep_seconds: int = 3600) -> None:
        self._jobs: dict[str, dict[str, Any]] = {}
        self._lock = threading.Lock()
        self._keep = keep_seconds

    def _cleanup(self) -> None:
        now = time.time()
        for jid in [j for j, v in self._jobs.items() if v.get("finished_at") and now - v["finished_at"] > self._keep]:
            del self._jobs[jid]

    def submit(self, fn: Callable[[Callable], Any]) -> str:
        """fn(progress) を別スレッドで実行する。progress(phase, current, total, message)。"""
        job_id = uuid.uuid4().hex[:12]
        with self._lock:
            self._cleanup()
            self._jobs[job_id] = {
                "id": job_id, "status": "running", "phase": "queued", "current": 0, "total": 0,
                "message": "待機中", "result": None, "error": None,
                "started_at": time.time(), "finished_at": None,
            }

        def progress(phase: str, current: int, total: int, message: str) -> None:
            with self._lock:
                self._jobs[job_id].update(phase=phase, current=current, total=total, message=message)

        def run() -> None:
            try:
                result = fn(progress)
                with self._lock:
                    self._jobs[job_id].update(status="done", result=result, finished_at=time.time())
            except Exception as exc:  # noqa: BLE001 - 画面にエラー内容を返すため
                traceback.print_exc()
                with self._lock:
                    self._jobs[job_id].update(status="error", error=str(exc), finished_at=time.time())

        threading.Thread(target=run, daemon=True, name=f"job-{job_id}").start()
        return job_id

    def get(self, job_id: str) -> dict | None:
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None:
                return None
            data = dict(job)
        data["elapsed_sec"] = round((data["finished_at"] or time.time()) - data["started_at"], 1)
        return data


jobs = JobManager()
